"""Lightweight web UI: chat with the latest reports, browse reports, trigger a run.

    streamlit run streamlit_app.py
"""
from __future__ import annotations

import uuid

import streamlit as st

from report_agent.chat_graph import ChatSession
from report_agent.config import get_settings
from report_agent.llm import get_chat_model
from report_agent.logging_setup import setup_logging
from report_agent.report_graph import run_report_cycle
from report_agent.scheduler import start_background
from report_agent.storage import ReportStore

settings = get_settings()
setup_logging(settings.log_dir)
st.set_page_config(page_title="GenAI Report Agent", page_icon="📰", layout="wide")


@st.cache_resource
def scheduler():
    """One background APScheduler per server process: reports keep refreshing hourly while users chat."""
    return start_background()


@st.cache_resource
def llm():
    return get_chat_model(settings)


store = ReportStore(settings.data_dir)

with st.sidebar:
    st.header("📰 Report agent")
    model = llm()
    st.caption(f"Model: `{model.name if model else 'offline (extractive + retrieval)'}` · "
               f"sources: `{settings.source_mode}`")
    if st.toggle("Hourly background schedule", value=False,
                 help=f"Runs a report cycle now and then every {settings.schedule_minutes} min"):
        sched = scheduler()
        job = sched.get_job("hourly_report")
        st.caption(f"Next run: {job.next_run_time:%H:%M:%S}" if job else "")
    if st.button("Generate reports now", use_container_width=True):
        with st.spinner("Fetching, summarising and evaluating…"):
            made = run_report_cycle(print_reports=False)
        st.success(f"{len(made)} new report(s)" if made else "No new articles — reports are current.")
    if st.button("New conversation", use_container_width=True):
        st.session_state.pop("chat", None)
        st.session_state.pop("history", None)

    st.subheader("Latest reports")
    for r in store.latest_per_topic():
        ev = r.evaluation
        with st.expander(f"{r.topic} · {r.created_at[11:16]} UTC"):
            st.markdown(r.to_markdown().split("## Evaluation")[0])
            if ev:
                st.caption(f"Eval: {'✅ passed' if ev.passed else '⚠️ failed'} · score {ev.score:.2f} · "
                           f"{ev.checks.get('summary_word_count')} words · revisions {r.revisions}")

st.title("Ask about the latest news")
st.caption("Answers are grounded in the hourly reports. Try “What’s happening nowadays?” or "
           "“What’s new in AI today?”")

if "chat" not in st.session_state:
    st.session_state.chat = ChatSession(thread_id=uuid.uuid4().hex[:8], llm=llm(), use_llm=llm() is not None)
    st.session_state.history = []

for role, text, meta in st.session_state.history:
    with st.chat_message(role):
        st.markdown(text)
        if meta:
            st.caption(meta)

if question := st.chat_input("Ask a question…"):
    st.session_state.history.append(("user", question, None))
    with st.chat_message("user"):
        st.markdown(question)
    with st.chat_message("assistant"):
        with st.spinner("Thinking…"):
            out = st.session_state.chat.ask(question)
        meta = f"intent: {out['intent']} · " + " · ".join(
            f"[{c['id']}] {c['topic']} ({c['created_at'][11:16]} UTC)" for c in out["citations"])
        st.markdown(out["answer"])
        st.caption(meta)
    st.session_state.history.append(("assistant", out["answer"], meta))
