import json
import os

import pytest

os.environ["SOURCE_MODE"] = "fixtures"

from report_agent.chat_graph import ChatSession, detect_topic  # noqa: E402
from report_agent.config import get_settings  # noqa: E402
from report_agent.evaluation import evaluate_report  # noqa: E402
from report_agent.report_graph import build_report_graph, run_report_cycle  # noqa: E402
from report_agent.schemas import Article, Entities, ReportDraft  # noqa: E402
from report_agent.sources import clean_text, extract_article_text, filter_relevant, parse_feed  # noqa: E402
from report_agent.storage import ReportStore  # noqa: E402
from report_agent.summarise import extractive_report  # noqa: E402
from tests.fake_llm import FakeLLM  # noqa: E402


@pytest.fixture
def settings(tmp_path, monkeypatch):
    monkeypatch.setenv("SOURCE_MODE", "fixtures")
    monkeypatch.setenv("LLM_PROVIDER", "offline")
    monkeypatch.setenv("DATA_DIR", str(tmp_path / "data"))
    return get_settings()


# ----------------------------------------------------------------------------- collection
RSS = """<?xml version="1.0"?><rss><channel>
<item><title>AI safety bill published</title><link>https://www.bbc.co.uk/news/articles/abc?at=1</link>
<description>The government publishes an AI bill.</description><pubDate>Wed, 29 Oct 2026 09:00:00 GMT</pubDate></item>
</channel></rss>"""


def test_parse_rss_strips_tracking_and_parses_date():
    [a] = parse_feed(RSS, "BBC", "rss")
    assert a.url == "https://www.bbc.co.uk/news/articles/abc"
    assert a.published.startswith("2026-10-29T09:00")


def test_extract_bbc_text_blocks_and_clean():
    html = ("<html><body><nav>Home News Sport</nav><article>"
            + "".join(f'<div data-component="text-block"><p>Paragraph {i} about artificial intelligence '
                      f'regulation in the United Kingdom today.</p></div>' for i in range(10))
            + '<div data-component="text-block"><p>Image source, Getty Images</p></div></article></body></html>')
    text = clean_text(extract_article_text(html))
    assert "Paragraph 0" in text and "Getty" not in text and "Home News" not in text


def test_relevance_filter_separates_topics(settings):
    from report_agent.sources import load_fixture_articles
    arts = load_fixture_articles(settings.fixtures_dir, 1)
    econ = filter_relevant(arts, "UK Economy")
    assert any("interest rates" in a.title.lower() for a in econ)
    assert not any("quantum" in a.title.lower() for a in econ)


# ----------------------------------------------------------------------------- summarisation & eval
def test_extractive_report_meets_format(settings):
    from report_agent.sources import load_fixture_articles
    arts = filter_relevant(load_fixture_articles(settings.fixtures_dir, 1), "AI Regulation")
    draft = extractive_report(arts)
    assert 100 <= len(draft.summary.split()) <= 150
    assert 3 <= len(draft.key_takeaways) <= 5
    assert draft.entities.organisations


def test_evaluator_catches_hallucinated_numbers_and_length():
    art = Article(url="u", title="Rates held", source="s", text="The board held rates at 3.75% on Thursday. " * 5)
    bad = ReportDraft(summary="Rates were cut to 2.5% today.", key_takeaways=["Rates cut"],
                      entities=Entities(organisations=["Imaginary Bank"]))
    res = evaluate_report(bad, [art], "UK Economy")
    assert not res.passed
    assert not res.checks["numbers_grounded"] and not res.checks["summary_length_ok"]
    assert any("2.5" in f for f in res.feedback)


# ----------------------------------------------------------------------------- graph
def test_report_cycle_dedupes_across_runs(settings):
    first = run_report_cycle(["UK Economy"], settings=settings, print_reports=False)
    second = run_report_cycle(["UK Economy"], settings=settings, print_reports=False)   # batch 2 arrives
    third = run_report_cycle(["UK Economy"], settings=settings, print_reports=False)    # nothing new
    assert len(first) == 1 and len(second) == 1 and third == []
    urls1 = {s["url"] for s in first[0].sources}
    new2 = {s["url"] for s in second[0].sources if not s["background"]}
    assert urls1.isdisjoint(new2)
    store = ReportStore(settings.data_dir)
    assert (store.reports_dir / f"{first[0].id}.md").exists()
    assert json.loads((settings.data_dir / "runs.json").read_text())[-1]["outcome"]["UK Economy"] == "no_new_articles"


def test_llm_path_revises_until_evaluation_passes(settings):
    fake = FakeLLM(bad_first_draft=True, calls={})
    graph = build_report_graph(settings, llm=fake)
    out = graph.invoke({"topic": "UK Economy", "run_id": "t", "messages": [], "errors": []})
    report = out["report"]
    assert report.revisions == 1, "first draft is too short, so exactly one revision is expected"
    assert report.evaluation.passed
    assert report.method == "llm:fake" or report.method.startswith("llm:")
    assert report.evaluation.checks["judge_faithfulness"] == 5


# ----------------------------------------------------------------------------- chat
def test_detect_topic():
    assert detect_topic("what's going on with inflation?") == "UK Economy"
    assert detect_topic("hello there") is None


def test_chat_offline_vague_followup_and_out_of_scope(settings):
    run_report_cycle(settings=settings, print_reports=False)
    chat = ChatSession(thread_id="t1", settings=settings, use_llm=False)
    overview = chat.ask("What's happening nowadays?")
    assert overview["intent"] == "overview" and len({c["topic"] for c in overview["citations"]}) >= 2
    chat.ask("Tell me about AI regulation")
    follow = chat.ask("What about the economy?")
    assert follow["intent"] == "followup" and follow["citations"][0]["topic"] == "UK Economy"
    oos = chat.ask("Who won the Champions League final?")
    assert "don't seem to cover" in oos["answer"]


def test_chat_llm_path_rewrites_followups_and_cites(settings):
    run_report_cycle(settings=settings, print_reports=False)
    chat = ChatSession(thread_id="t2", settings=settings, llm=FakeLLM(calls={}))
    chat.ask("What did the Monetary Policy Board decide?")
    out = chat.ask("Why did they do that?")
    assert out["intent"] == "followup" and out["query"] == "UK economy interest rates"
    assert "[R1]" in out["answer"]


def test_missing_entities_are_backfilled(settings):
    from report_agent.report_graph import _ensure_entities
    from report_agent.sources import load_fixture_articles
    arts = filter_relevant(load_fixture_articles(settings.fixtures_dir, 1), "UK Economy")
    draft = ReportDraft.model_validate_json('{"summary": "s", "key_takeaways": ["a", "b", "c"]}')
    assert _ensure_entities(draft, arts).entities.organisations
