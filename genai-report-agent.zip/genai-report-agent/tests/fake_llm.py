"""A deterministic stand-in for a real chat model so the LLM code paths (map-reduce, structured output,
revise loop, judge, query rewriting, grounded answers) can be tested without an API key."""
from __future__ import annotations

import re
from typing import Any

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from langchain_core.runnables import RunnableLambda

from report_agent.evaluation import JudgeVerdict
from report_agent.schemas import Entities, ReportDraft


def _text(messages) -> str:
    if hasattr(messages, "to_messages"):
        messages = messages.to_messages()
    return "\n".join(m.content for m in messages)


class FakeLLM(BaseChatModel):
    """`bad_first_draft=True` makes the first ReportDraft too short, forcing one revise iteration."""
    bad_first_draft: bool = True
    calls: dict = {}

    @property
    def _llm_type(self) -> str:
        return "fake"

    def _generate(self, messages: list[BaseMessage], stop=None, run_manager=None, **kw: Any) -> ChatResult:
        self.calls["generate"] = self.calls.get("generate", 0) + 1
        txt = _text(messages)
        if "Condense the article" in txt:            # map step: first two sentences of the article body
            body = txt.split("Published:", 1)[-1].split("\n", 2)[-1]
            out = " ".join(re.split(r"(?<=[.!?])\s+", body.strip())[:2])
        elif "standalone search query" in txt:       # rewrite step
            out = "UK economy interest rates"
        elif "CONTEXT:" in txt:                      # grounded answer
            first = re.search(r"Key takeaways:\n- (.+)", txt)
            out = f"According to the latest report, {first.group(1) if first else 'nothing new'} [R1]"
        else:
            out = "Hello! Ask me about the latest news."
        return ChatResult(generations=[ChatGeneration(message=AIMessage(content=out))])

    def with_structured_output(self, schema, **kwargs):
        def run(prompt_value):
            txt = _text(prompt_value)
            if schema is JudgeVerdict:
                return JudgeVerdict(faithfulness=5, relevance=5, issues=[])
            n = self.calls.get("draft", 0)
            self.calls["draft"] = n + 1
            notes = txt.split("Article notes:", 1)[-1]
            sents = [s for s in re.split(r"(?<=[.!?])\s+", re.sub(r"\[\d+\][^\n]*\n", "", notes)) if len(s.split()) > 5]
            if self.bad_first_draft and n == 0:
                summary = " ".join(sents[:1])                   # deliberately too short
            else:
                summary, words = [], 0
                for s in sents:
                    if words + len(s.split()) > 150:
                        break
                    summary.append(s)
                    words += len(s.split())
                    if words >= 110:
                        break
                summary = " ".join(summary)
            orgs = sorted(set(re.findall(r"(?:[A-Z][a-z]+ ){1,3}(?:Board|Bureau|Standards|Commission|Treasury)", notes)))
            return ReportDraft(summary=summary, key_takeaways=sents[:4],
                               entities=Entities(organisations=[o.strip() for o in orgs][:5], terms=[], topics=[]))
        return RunnableLambda(run)
