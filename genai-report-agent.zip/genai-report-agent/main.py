"""GenAI Report Agent — command-line entry point.

  python main.py report  [--topic "AI Regulation"]     run one reporting cycle now (manual trigger)
  python main.py schedule [--minutes 60]               run a cycle immediately, then every hour
  python main.py chat                                  chat with the latest reports in the terminal
  python main.py eval                                  run report + chat evaluations
  python main.py demo                                  offline end-to-end demo (sample data, 2 cycles, chat, eval)

Global flags: --offline (sample fixtures instead of live scraping) · --no-llm (extractive baseline)
"""
from __future__ import annotations

import argparse
import os
import sys
import uuid
from pathlib import Path


def _apply_flags(args) -> None:
    if args.offline:
        os.environ["SOURCE_MODE"] = "fixtures"
    if args.no_llm:
        os.environ["LLM_PROVIDER"] = "offline"
    if args.data_dir:
        os.environ["DATA_DIR"] = args.data_dir


def cmd_report(args) -> None:
    from report_agent.report_graph import run_report_cycle
    reports = run_report_cycle([args.topic] if args.topic else None)
    if not reports:
        print("No new reports were produced. If errors are shown above, they explain why; "
              "otherwise there were no new articles since the last run (see logs/agent.jsonl).")


def cmd_schedule(args) -> None:
    from report_agent.scheduler import run_forever
    run_forever([args.topic] if args.topic else None, minutes=args.minutes)


def cmd_chat(args) -> None:
    from report_agent.chat_graph import ChatSession
    from report_agent.llm import get_chat_model
    from report_agent.config import get_settings
    llm = get_chat_model(get_settings())
    session = ChatSession(thread_id=uuid.uuid4().hex[:8], llm=llm)
    print(f"News Briefing Assistant ({'LLM: ' + llm.name if llm else 'offline retrieval mode'}). "
          "Ask anything about the latest reports — e.g. “What’s happening nowadays?”. Type 'exit' to quit.\n")
    while True:
        try:
            q = input("you › ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if q.lower() in {"exit", "quit", ":q"}:
            break
        if not q:
            continue
        out = session.ask(q)
        print(f"\nassistant › {out['answer']}\n")
        for c in out["citations"]:
            print(f"   [{c['id']}] {c['topic']} report · {c['created_at']}")
        print()


def cmd_eval(args) -> None:
    from report_agent.evals import run_all
    res = run_all(Path(args.out))
    print(f"Reports: {res['reports']['reports']} · pass rate {res['reports']['pass_rate']:.0%} · "
          f"mean score {res['reports']['mean_score']}")
    print(f"Chat:    {res['chat']['turns']} turns · pass rate {res['chat']['pass_rate']:.0%}")
    print(f"Details: {Path(args.out) / 'eval_results.md'}")


def cmd_demo(args) -> None:
    """Simulates two hourly ticks on sample data, then chats and evaluates — no network or API key needed."""
    os.environ["SOURCE_MODE"] = "fixtures"
    from report_agent.chat_graph import ChatSession
    from report_agent.evals import run_all
    from report_agent.report_graph import run_report_cycle

    print("=" * 70, "\nTICK 1 (simulated 10:00)\n" + "=" * 70)
    run_report_cycle()
    print("=" * 70, "\nTICK 2 (simulated 11:00) — only new articles are processed\n" + "=" * 70)
    run_report_cycle()
    print("=" * 70, "\nTICK 3 — no new articles\n" + "=" * 70)
    if not run_report_cycle():
        print("No new articles — reports unchanged (de-duplication working).")

    print("=" * 70, "\nCHAT\n" + "=" * 70)
    session = ChatSession(thread_id="demo")
    for q in ["What's happening nowadays?", "What's new in AI today?", "What about the economy?",
              "Did interest rates change?", "Who won the Champions League final?"]:
        out = session.ask(q)
        print(f"\nyou › {q}\n[intent={out['intent']} · query='{out['query']}']\nassistant › {out['answer']}")

    print("\n" + "=" * 70, "\nEVALUATION\n" + "=" * 70)
    res = run_all(Path(args.out))
    print(f"Reports pass rate {res['reports']['pass_rate']:.0%} (mean score {res['reports']['mean_score']}); "
          f"chat pass rate {res['chat']['pass_rate']:.0%}. See {Path(args.out) / 'eval_results.md'}")


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(description="GenAI Report Agent")
    p.add_argument("--offline", action="store_true", help="use bundled sample articles instead of live scraping")
    p.add_argument("--no-llm", action="store_true", help="force the extractive / retrieval-only baseline")
    p.add_argument("--data-dir", help="where reports are stored (default ./data)")
    sub = p.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("report"); r.add_argument("--topic"); r.set_defaults(fn=cmd_report)
    sc = sub.add_parser("schedule"); sc.add_argument("--topic"); sc.add_argument("--minutes", type=int)
    sc.set_defaults(fn=cmd_schedule)
    sub.add_parser("chat").set_defaults(fn=cmd_chat)
    e = sub.add_parser("eval"); e.add_argument("--out", default="examples"); e.set_defaults(fn=cmd_eval)
    d = sub.add_parser("demo"); d.add_argument("--out", default="examples"); d.set_defaults(fn=cmd_demo)
    args = p.parse_args(argv)
    _apply_flags(args)

    from report_agent.config import get_settings
    from report_agent.logging_setup import setup_logging
    setup_logging(get_settings().log_dir)
    args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
