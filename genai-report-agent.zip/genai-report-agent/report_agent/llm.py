"""Provider-agnostic chat-model factory (LangChain interfaces only).

`LLM_PROVIDER=auto` picks Anthropic, then OpenAI, then a local Ollama server if
configured, otherwise returns None and the system runs in *offline* mode
(extractive summarisation + retrieval-only answers). Offline mode exists so the
project is testable without any API key; it is a baseline, not the main path.
"""
from __future__ import annotations

import os

from langchain_core.language_models import BaseChatModel

from .config import Settings
from .logging_setup import get_logger

log = get_logger("llm")

DEFAULT_MODELS = {
    "anthropic": "claude-sonnet-5-5",
    "openai": "gpt-4o-mini",
    "ollama": "llama3.1",
}


def resolve_provider(settings: Settings) -> str:
    p = settings.llm_provider.lower()
    if p != "auto":
        return p
    if os.getenv("ANTHROPIC_API_KEY"):
        return "anthropic"
    if os.getenv("OPENAI_API_KEY"):
        return "openai"
    if os.getenv("OLLAMA_BASE_URL"):
        return "ollama"
    return "offline"


def get_chat_model(settings: Settings) -> BaseChatModel | None:
    provider = resolve_provider(settings)
    model = settings.llm_model or DEFAULT_MODELS.get(provider)
    try:
        if provider == "anthropic":
            from langchain_anthropic import ChatAnthropic
            # Newer Claude models reject non-default sampling params, so temperature is not sent.
            llm = ChatAnthropic(model=model, max_tokens=1500, max_retries=3)
        elif provider == "openai":
            from langchain_openai import ChatOpenAI
            llm = ChatOpenAI(model=model, temperature=settings.llm_temperature, max_retries=3)
        elif provider == "ollama":
            from langchain_ollama import ChatOllama
            llm = ChatOllama(model=model, temperature=settings.llm_temperature,
                             base_url=os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"))
        else:
            return None
    except ImportError as exc:
        log.warning("LLM provider %s unavailable (%s) — falling back to offline mode", provider, exc)
        return None
    llm.name = f"{provider}/{model}"  # used in report metadata / logs
    return llm


def model_label(llm: BaseChatModel | None) -> str:
    return f"llm:{llm.name}" if llm is not None else "extractive"


def structured(llm: BaseChatModel, schema):
    """Schema-constrained output. Anthropic's newer models use native JSON-schema output rather than
    forced tool calling; other providers use their default structured-output method."""
    if type(llm).__name__ == "ChatAnthropic":
        return llm.with_structured_output(schema, method="json_schema")
    return llm.with_structured_output(schema)
