"""Data collection: feed discovery (RSS/Atom), article scraping, cleaning and topic relevance.

Feeds are used for *discovery* (they are stable, cheap and list the newest items);
each article page is then scraped for its full body text with BeautifulSoup.
"""
from __future__ import annotations

import json
import re
from email.utils import parsedate_to_datetime
from pathlib import Path
from urllib.parse import urlencode

import requests
from bs4 import BeautifulSoup

from .config import TOPIC_KEYWORDS
from .logging_setup import get_logger, log_event
from .schemas import Article

log = get_logger("sources")

HEADERS = {"User-Agent": "Mozilla/5.0 (GenAI-Report-Agent; educational take-home project)"}

# Lines that are page furniture rather than article content.
BOILERPLATE_PATTERNS = [
    r"^image (source|caption)", r"^getty images$", r"^(follow|share|related topics|more on this story)",
    r"^(sign up|subscribe)", r"^watch:?", r"^listen:?", r"^copyright", r"^this video can not be played",
    r"^media caption", r"cookies", r"^skip to", r"^is this page useful", r"^published \d",
]
_BOILER_RE = re.compile("|".join(BOILERPLATE_PATTERNS), re.IGNORECASE)


# --------------------------------------------------------------------------- cleaning
def clean_text(raw: str, max_chars: int = 6000) -> str:
    """Normalise whitespace, drop boilerplate lines, de-duplicate repeated paragraphs."""
    seen: set[str] = set()
    kept: list[str] = []
    for line in re.split(r"\n+", raw or ""):
        line = re.sub(r"\s+", " ", line).strip()
        if len(line) < 25 or _BOILER_RE.search(line):
            continue
        key = line.lower()
        if key in seen:
            continue
        seen.add(key)
        kept.append(line)
    text = "\n".join(kept)
    return text[:max_chars].rsplit(" ", 1)[0] if len(text) > max_chars else text


def _iso(date_str: str | None) -> str | None:
    if not date_str:
        return None
    try:
        return parsedate_to_datetime(date_str).isoformat()  # RFC-822 (RSS)
    except (TypeError, ValueError):
        return date_str  # Atom is already ISO-8601


# --------------------------------------------------------------------------- feeds
def parse_feed(xml: str, source_name: str, kind: str) -> list[Article]:
    soup = BeautifulSoup(xml, "xml")
    items: list[Article] = []
    if kind == "rss":
        for it in soup.find_all("item"):
            link = (it.link.text if it.link else "").strip()
            if not link:
                continue
            items.append(Article(
                url=link.split("?")[0], title=(it.title.text if it.title else "").strip(),
                source=source_name, published=_iso(it.pubDate.text if it.pubDate else None),
                summary=BeautifulSoup(it.description.text if it.description else "", "lxml").get_text(" ").strip(),
            ))
    else:  # atom
        for e in soup.find_all("entry"):
            link_tag = e.find("link")
            link = link_tag.get("href", "") if link_tag else ""
            if not link:
                continue
            items.append(Article(
                url=link, title=(e.title.text if e.title else "").strip(), source=source_name,
                published=(e.updated.text if e.updated else None),
                summary=BeautifulSoup(e.summary.text if e.summary else "", "lxml").get_text(" ").strip(),
            ))
    return items


def fetch_feed(source: dict, topic: str | None = None, timeout: int = 15, limit: int = 25) -> list[Article]:
    url = source["url"]
    if source["kind"] == "atom" and topic and "gov.uk" in url:
        url = f"{url}?{urlencode({'keywords': topic, 'order': 'updated-newest'})}"
    resp = requests.get(url, headers=HEADERS, timeout=timeout)
    resp.raise_for_status()
    items = parse_feed(resp.text, source["name"], source["kind"])[:limit]
    log_event(log, "feed fetched", source=source["name"], items=len(items))
    return items


# --------------------------------------------------------------------------- article pages
def extract_article_text(html: str) -> str:
    """Site-aware body extraction with a generic fallback."""
    soup = BeautifulSoup(html, "lxml")
    for tag in soup(["script", "style", "nav", "footer", "header", "aside", "figure", "form"]):
        tag.decompose()
    selectors = [
        '[data-component="text-block"] p',   # BBC News
        ".govspeak p, .govspeak li",          # GOV.UK
        "article p",
        "main p",
    ]
    for sel in selectors:
        paras = [p.get_text(" ", strip=True) for p in soup.select(sel)]
        if sum(len(p) for p in paras) > 300:
            return "\n".join(paras)
    return "\n".join(p.get_text(" ", strip=True) for p in soup.find_all("p"))


def fetch_article(article: Article, timeout: int = 15, max_chars: int = 6000) -> Article:
    try:
        resp = requests.get(article.url, headers=HEADERS, timeout=timeout)
        resp.raise_for_status()
        text = clean_text(extract_article_text(resp.text), max_chars)
    except requests.RequestException as exc:
        log.warning("article fetch failed, using feed summary | url=%s err=%s", article.url, exc)
        text = ""
    article.text = text if len(text) > 200 else (article.summary or article.title)
    return article


# --------------------------------------------------------------------------- relevance
def topic_keywords(topic: str) -> list[str]:
    return TOPIC_KEYWORDS.get(topic) or [w.lower() for w in re.findall(r"[A-Za-z]{3,}", topic)]


def relevance_score(article: Article, topic: str) -> float:
    """Keyword-hit score; title hits weigh 3x. Cheap, transparent pre-filter before the LLM."""
    title, body = article.title.lower(), f"{article.summary} {article.text}".lower()
    score = 0.0
    for kw in topic_keywords(topic):
        pattern = rf"\b{re.escape(kw)}\b"
        score += 3 * len(re.findall(pattern, title)) + min(len(re.findall(pattern, body)), 5)
    return score


def filter_relevant(articles: list[Article], topic: str, min_score: float = 3.0) -> list[Article]:
    scored = sorted(((relevance_score(a, topic), a) for a in articles), key=lambda x: -x[0])
    return [a for s, a in scored if s >= min_score]


# --------------------------------------------------------------------------- offline fixtures
def load_fixture_articles(fixtures_dir: Path, upto_batch: int) -> list[Article]:
    """Sample articles for offline demos/tests. Batches simulate news arriving over time."""
    out: list[Article] = []
    for path in sorted(fixtures_dir.glob("batch_*.json")):
        batch_no = int(re.search(r"(\d+)", path.stem).group(1))
        if batch_no <= upto_batch:
            out += [Article(**a) for a in json.loads(path.read_text(encoding="utf-8"))]
    return out
