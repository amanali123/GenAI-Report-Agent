"""File-based persistence: reports (JSON + Markdown), seen-article index, run counter.

A JSON-on-disk store keeps the project dependency-free and easy to inspect;
`ReportStore` is the only place that touches these files, so swapping in SQLite
or a vector DB later is a one-class change.
"""
from __future__ import annotations

import json
from pathlib import Path

from .schemas import Report


class ReportStore:
    def __init__(self, data_dir: Path):
        self.data_dir = Path(data_dir)
        self.reports_dir = self.data_dir / "reports"
        self.reports_dir.mkdir(parents=True, exist_ok=True)
        self._seen_path = self.data_dir / "seen_urls.json"
        self._runs_path = self.data_dir / "runs.json"

    # ---------------------------------------------------------------- reports
    def save_report(self, report: Report) -> Path:
        stem = self.reports_dir / report.id
        stem.with_suffix(".json").write_text(report.model_dump_json(indent=2), encoding="utf-8")
        stem.with_suffix(".md").write_text(report.to_markdown(), encoding="utf-8")
        return stem.with_suffix(".md")

    def list_reports(self, topic: str | None = None, limit: int | None = None) -> list[Report]:
        """Newest first."""
        reports = [Report.model_validate_json(p.read_text(encoding="utf-8"))
                   for p in self.reports_dir.glob("*.json")]
        if topic:
            reports = [r for r in reports if r.topic.lower() == topic.lower()]
        reports.sort(key=lambda r: (r.created_at, r.id), reverse=True)
        return reports[:limit] if limit else reports

    def latest_per_topic(self) -> list[Report]:
        latest: dict[str, Report] = {}
        for r in self.list_reports():
            latest.setdefault(r.topic, r)
        return sorted(latest.values(), key=lambda r: r.created_at, reverse=True)

    # ---------------------------------------------------------------- dedupe
    def seen_urls(self, topic: str) -> set[str]:
        data = self._read(self._seen_path, {})
        return set(data.get(topic, []))

    def mark_seen(self, topic: str, urls: list[str]) -> None:
        data = self._read(self._seen_path, {})
        data[topic] = sorted(set(data.get(topic, [])) | set(urls))
        self._seen_path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    # ---------------------------------------------------------------- article cache
    def save_articles(self, topic: str, articles: list) -> None:
        path = self.data_dir / "articles.jsonl"
        with path.open("a", encoding="utf-8") as fh:
            for a in articles:
                fh.write(json.dumps({"topic": topic, **a.model_dump()}) + "\n")

    def recent_articles(self, topic: str, limit: int, exclude: set[str]) -> list[dict]:
        path = self.data_dir / "articles.jsonl"
        if not path.exists():
            return []
        rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
        rows = [r for r in rows if r["topic"] == topic and r["url"] not in exclude and not r.get("background")]
        rows.sort(key=lambda r: r.get("published") or "", reverse=True)
        out, seen = [], set()
        for r in rows:
            if r["url"] not in seen:
                seen.add(r["url"])
                out.append(r)
        return out[:limit]

    # ---------------------------------------------------------------- run log
    def record_run(self, summary: dict) -> int:
        runs = self._read(self._runs_path, [])
        runs.append(summary)
        self._runs_path.write_text(json.dumps(runs, indent=2, default=str), encoding="utf-8")
        return len(runs)

    def run_count(self) -> int:
        return len(self._read(self._runs_path, []))

    @staticmethod
    def _read(path: Path, default):
        if not path.exists():
            return default
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            return default
