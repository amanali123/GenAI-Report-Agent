"""Retrieval over generated reports (+ the articles behind them) for the chat agent.

Corpus is small (tens to hundreds of chunks), so a dependency-free BM25 with a recency
prior is fast, transparent and good enough; see WRITEUP.md for the embeddings trade-off.
"""
from __future__ import annotations

import math
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone

from .schemas import Report
from .storage import ReportStore
from .summarise import _tokens


@dataclass
class Chunk:
    text: str
    report_id: str
    topic: str
    created_at: str
    kind: str          # summary | takeaway | article
    url: str | None = None
    title: str | None = None
    score: float = 0.0
    coverage: float = 0.0   # share of the query's content words found in this chunk


class BM25:
    def __init__(self, docs: list[list[str]], k1: float = 1.4, b: float = 0.75):
        self.docs, self.k1, self.b = docs, k1, b
        self.avgdl = sum(map(len, docs)) / max(len(docs), 1)
        df = Counter(t for d in docs for t in set(d))
        n = len(docs)
        self.idf = {t: math.log(1 + (n - c + 0.5) / (c + 0.5)) for t, c in df.items()}
        self.tfs = [Counter(d) for d in docs]

    def score(self, query: list[str], i: int) -> float:
        tf, dl = self.tfs[i], len(self.docs[i])
        s = 0.0
        for q in query:
            if q in tf:
                s += self.idf[q] * tf[q] * (self.k1 + 1) / (tf[q] + self.k1 * (1 - self.b + self.b * dl / self.avgdl))
        return s


def _stem(t: str) -> str:
    for suf in ("ing", "ies", "es", "s", "ed"):
        if len(t) > 4 and t.endswith(suf):
            return t[: -len(suf)]
    return t


def tokenize(text: str) -> list[str]:
    return [_stem(t) for t in _tokens(text)]


def build_chunks(reports: list[Report], store: ReportStore) -> list[Chunk]:
    chunks: list[Chunk] = []
    for r in reports:
        chunks.append(Chunk(r.summary, r.id, r.topic, r.created_at, "summary"))
        chunks += [Chunk(t, r.id, r.topic, r.created_at, "takeaway") for t in r.key_takeaways]
        for src in r.sources:
            if src.get("background"):
                continue
            chunks.append(Chunk(src["title"], r.id, r.topic, r.created_at, "article", src["url"], src["title"]))
    # enrich article chunks with the cached body text (first ~3 sentences) when available
    bodies = {a["url"]: a["text"] for topic in {r.topic for r in reports}
              for a in store.recent_articles(topic, 500, exclude=set())}
    for c in chunks:
        if c.kind == "article" and c.url in bodies:
            c.text = f"{c.title}. " + " ".join(bodies[c.url].split(". ")[:3])
    return chunks


# Words that say "how" to search (recency, generality) rather than "what" — excluded from matching.
QUERY_NOISE = {"today", "latest", "news", "recent", "recently", "happening", "update", "updat", "now", "week",
               "current", "currently", "tell", "know", "anything", "chang", "change", "did", "does", "what's",
               "whats", "going", "nowadays", "happen", "there", "any", "about", "regarding"}


def query_terms(query: str) -> list[str]:
    return [t for t in tokenize(query) if t not in QUERY_NOISE]


def search(chunks: list[Chunk], query: str, k: int = 6, topic: str | None = None) -> list[Chunk]:
    if not chunks:
        return []
    docs = [tokenize(c.text) for c in chunks]
    bm = BM25(docs)
    q = query_terms(query)
    if not q:
        return []
    newest = max(c.created_at for c in chunks)
    out = []
    for i, c in enumerate(chunks):
        base = bm.score(q, i)
        if base <= 0:
            continue
        age_h = max((_ts(newest) - _ts(c.created_at)) / 3600, 0)
        recency = 1 / (1 + age_h / 24)                # newer reports win ties
        topical = 1.25 if topic and c.topic == topic else 1.0
        c.score = round(base * (0.8 + 0.2 * recency) * topical, 3)
        c.coverage = round(len(set(q) & set(docs[i])) / len(set(q)), 2)
        out.append(c)
    out.sort(key=lambda c: -c.score)
    return out[:k]


def _ts(iso: str) -> float:
    try:
        return datetime.fromisoformat(iso).timestamp()
    except ValueError:
        return datetime.now(timezone.utc).timestamp()
