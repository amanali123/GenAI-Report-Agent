"""Summarisation techniques.

LLM path (map-reduce):
  * map   – each article is condensed to a short, fact-dense note (bounded context per call,
            parallelised with `.batch`).
  * reduce – the notes are synthesised into a structured `ReportDraft` via
            `with_structured_output` (schema-constrained generation, no fragile parsing).
  * revise – if evaluation fails, the draft + concrete evaluator feedback go back to the model.

Extractive path (offline baseline): centroid-based sentence ranking with a word-budget
knapsack to land inside the 100–150 word window, plus heuristic entity extraction.
"""
from __future__ import annotations

import math
import re
from collections import Counter

from langchain_core.language_models import BaseChatModel
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate

from .llm import structured
from .schemas import Article, Entities, ReportDraft

# ============================================================================ LLM path
MAP_PROMPT = ChatPromptTemplate.from_messages([
    ("system",
     "You are a news analyst. Condense the article into 2-4 factual sentences relevant to the topic "
     "'{topic}'. Keep names of organisations, figures, dates and policy terms. No opinions, no "
     "information that is not in the article. If the article is not relevant to the topic, reply "
     "exactly: NOT_RELEVANT"),
    ("human", "Title: {title}\nSource: {source}\nPublished: {published}\n\n{text}"),
])

REDUCE_PROMPT = ChatPromptTemplate.from_messages([
    ("system",
     "You write hourly briefing reports on '{topic}' for busy readers.\n"
     "Using ONLY the article notes provided, produce:\n"
     "1. summary: ONE paragraph of 100-150 words (count carefully) that synthesises the main "
     "developments across articles rather than listing them one by one.\n"
     "2. key_takeaways: 3-5 distinct, specific, one-sentence takeaways.\n"
     "3. entities: organisations, technical/policy terms, and broad topics that are explicitly "
     "mentioned in the notes.\n"
     "Never invent facts, numbers or names that are not in the notes."),
    ("human", "Article notes:\n\n{notes}"),
])

REVISE_PROMPT = ChatPromptTemplate.from_messages([
    ("system",
     "You are revising a briefing report on '{topic}'. Fix every problem listed in the feedback, "
     "keep all content grounded in the article notes, and return the full corrected report."),
    ("human", "Article notes:\n\n{notes}\n\nPrevious draft:\n{draft}\n\nEvaluator feedback:\n{feedback}"),
])


def map_summaries(llm: BaseChatModel, articles: list[Article], topic: str) -> list[str]:
    chain = MAP_PROMPT | llm | StrOutputParser()
    inputs = [{"topic": topic, "title": a.title, "source": a.source, "published": a.published or "unknown",
               "text": a.text[:6000]} for a in articles]
    outs = chain.batch(inputs, config={"max_concurrency": 4})
    return [o.strip() for o in outs]


def format_notes(articles: list[Article], notes: list[str]) -> str:
    return "\n\n".join(f"[{i}] {a.title} ({a.source})\n{n}" for i, (a, n) in enumerate(zip(articles, notes), 1))


def reduce_report(llm: BaseChatModel, notes: str, topic: str) -> ReportDraft:
    return (REDUCE_PROMPT | structured(llm, ReportDraft)).invoke({"topic": topic, "notes": notes})


def revise_report(llm: BaseChatModel, notes: str, topic: str, draft: ReportDraft, feedback: list[str]) -> ReportDraft:
    return (REVISE_PROMPT | structured(llm, ReportDraft)).invoke({
        "topic": topic, "notes": notes, "draft": draft.model_dump_json(indent=2),
        "feedback": "\n".join(f"- {f}" for f in feedback),
    })


# ============================================================================ extractive path
STOPWORDS = set("""a about above after again against all also am an and any are as at be because been before being
below between both but by can could did do does doing down during each few for from further had has have having he
her here hers him his how i if in into is it its itself just me more most my no nor not now of off on once only or
other our out over own said same says she should so some such than that the their them then there these they this
those through to too under until up very was we were what when where which while who whom why will with would you
your new year years one two may like make made week told per cent also its it's without high however
expected among including could would still many much well first last next three four five six""".split())

_SENT_RE = re.compile(r"(?<=[.!?])\s+(?=[A-Z\"'‘“])")


def split_sentences(text: str) -> list[str]:
    return [s.strip() for s in _SENT_RE.split(re.sub(r"\s+", " ", text)) if 6 <= len(s.split()) <= 45]


_SHORT_KEEP = {"ai", "uk", "eu", "5g"}


def _tokens(text: str) -> list[str]:
    return [w for w in re.findall(r"[a-z0-9][a-z0-9\-']+", text.lower())
            if w not in STOPWORDS and (len(w) > 2 or w in _SHORT_KEEP) and not w.isdigit()]


def _wc(text: str) -> int:
    return len(text.split())


def rank_sentences(articles: list[Article]) -> list[tuple[float, int, int, str]]:
    """Score each sentence by TF-IDF cosine similarity to the corpus centroid (+ lead bias)."""
    docs = [split_sentences(a.text) for a in articles]
    df: Counter = Counter()
    for sents in docs:
        df.update(set(t for s in sents for t in _tokens(s)))
    n_docs = max(len(docs), 1)
    idf = {t: math.log(1 + n_docs / c) for t, c in df.items()}
    centroid: Counter = Counter()
    for sents in docs:
        for s in sents:
            for t in _tokens(s):
                centroid[t] += idf[t]
    c_norm = math.sqrt(sum(v * v for v in centroid.values())) or 1.0

    ranked = []
    for d_i, sents in enumerate(docs):
        for s_i, s in enumerate(sents):
            vec = Counter({t: idf[t] for t in _tokens(s)})
            norm = math.sqrt(sum(v * v for v in vec.values())) or 1.0
            cos = sum(v * centroid[t] for t, v in vec.items()) / (norm * c_norm)
            lead_bonus = 0.15 if s_i == 0 else (0.05 if s_i == 1 else 0.0)
            ranked.append((cos + lead_bonus, d_i, s_i, s))
    ranked.sort(key=lambda x: -x[0])
    return ranked


def _too_similar(a: str, b: str, thresh: float = 0.5) -> bool:
    ta, tb = set(_tokens(a)), set(_tokens(b))
    return bool(ta and tb) and len(ta & tb) / min(len(ta), len(tb)) > thresh


def extractive_summary(articles: list[Article], lo: int = 100, hi: int = 150) -> str:
    """Pick high-centrality, non-redundant sentences until the word budget is in [lo, hi]."""
    ranked = rank_sentences(articles)
    chosen: list[tuple[int, int, str]] = []
    words = 0
    per_doc: Counter = Counter()
    for _, d_i, s_i, s in ranked:
        if words >= lo:
            break
        if words + _wc(s) > hi or per_doc[d_i] >= 2 or any(_too_similar(s, c[2]) for c in chosen):
            continue
        chosen.append((d_i, s_i, s))
        per_doc[d_i] += 1
        words += _wc(s)
    if words < lo:  # relax constraints if the corpus is tiny
        for _, d_i, s_i, s in ranked:
            if words >= lo:
                break
            if (d_i, s_i, s) not in chosen and words + _wc(s) <= hi:
                chosen.append((d_i, s_i, s))
                words += _wc(s)
    # Present in article order, then sentence order, for readability
    chosen.sort(key=lambda c: (c[0], c[1]))
    return " ".join(c[2] for c in chosen)


def extractive_takeaways(articles: list[Article], k: int = 5) -> list[str]:
    """One takeaway per top-ranked article: its most central sentence (or its lead)."""
    best: dict[int, tuple[float, str]] = {}
    for score, d_i, _, s in rank_sentences(articles):
        if d_i not in best:
            best[d_i] = (score, s)
    picks = sorted(best.values(), key=lambda x: -x[0])
    out: list[str] = []
    for _, s in picks:
        if not any(_too_similar(s, o) for o in out):
            out.append(s)
        if len(out) == k:
            break
    # guarantee at least 3 takeaways when there are fewer articles
    for _, _, _, s in rank_sentences(articles):
        if len(out) >= 3:
            break
        if s not in out and not any(_too_similar(s, o) for o in out):
            out.append(s)
    return out


# ---------------------------------------------------------------------------- entities
ORG_HINTS = re.compile(
    r"\b(Bank|Office|Department|Ministry|Authority|Agency|Institute|Council|Commission|Committee|Treasury|"
    r"Ofcom|Ofgem|Ofwat|NHS|Parliament|Government|Union|Group|Ltd|plc|Inc|University|Association|Board|"
    r"Services|Security|Markets|Labs?|Technologies|Systems|Corporation|Company|Federation|Centre|Bureau|"
    r"Alliance|Forum|Research|Robotics|Hub|Collective|Partners|Capital|Holdings)\b")
_COMPANY_AI = re.compile(r"^[A-Z][a-z]+ AI$")  # e.g. "Meridian AI"
_GENERIC_ORG_WORDS = {"Security", "Government", "Services", "Group", "Company", "Board", "Office", "Department",
                      "Markets", "Systems", "Union", "Research", "AI", "Hub", "Bank", "Council", "Labs", "Lab"}
TERM_HINTS = re.compile(
    r"\b(Act|Bill|AI|artificial intelligence|regulation|framework|code of practice|model|inflation|"
    r"interest rates?|GDP|budget|chip|semiconductor|cyber|data|quantum|deepfake|copyright|growth|"
    r"broadband|cloud|open-source|tariff|wages|borrowing)\b", re.IGNORECASE)
_CAP_SEQ = re.compile(r"\b(?:[A-Z][a-zA-Z&\-]+|of|for|and|the)(?:\s+(?:[A-Z][a-zA-Z&\-]+|of|for|and|the))*\b")
_ACRONYM = re.compile(r"\b[A-Z]{2,6}\b")
_GENERIC = {"The", "But", "It", "This", "That", "In", "On", "A", "He", "She", "They", "We", "Mr", "Ms", "Dr",
            "However", "Meanwhile", "According", "There", "Its", "Their", "UK", "BBC News"}


def extract_entities(articles: list[Article], max_each: int = 10) -> Entities:
    text = " ".join(f"{a.title}. {a.text}" for a in articles)
    orgs: Counter = Counter()
    terms: Counter = Counter()
    for m in _CAP_SEQ.finditer(text):
        phrase = re.sub(r"^(?:[Tt]he|of|for|and)\s+|\s+(?:the|of|for|and)$", "", m.group(0)).strip()
        if not phrase or phrase in _GENERIC or len(phrase) < 3 or phrase.lower() in STOPWORDS:
            continue
        # a bare hint word ("Security", "Government") is not a named organisation
        if re.search(r"\b(Act|Bill|Strategy|Plan|Framework|Code)$", phrase):
            terms[phrase] += 1
        elif "-" not in phrase and phrase not in _GENERIC_ORG_WORDS and (
                ORG_HINTS.search(phrase) or _COMPANY_AI.match(phrase)):
            orgs[phrase] += 1
    for m in _ACRONYM.finditer(text):
        tok = m.group(0)
        if tok not in {"UK", "US", "AI", "BBC", "CEO", "TV", "PM", "MP", "MPS"}:
            orgs[tok] += 1
    for m in TERM_HINTS.finditer(text):
        terms[m.group(0) if m.group(0).isupper() else m.group(0).lower()] += 1

    def top(c: Counter) -> list[str]:
        items = [k for k, _ in c.most_common(40)]
        # drop entries that are substrings of a longer kept entry (e.g. "Bank" vs "Bank of England")
        kept = [k for k in items if not any(k != o and k in o for o in items)]
        return kept[:max_each]

    # Topics: content words shared by several articles (document frequency >= 2), i.e. recurring themes
    df: Counter = Counter(t for a in articles for t in set(_tokens(f"{a.title} {a.text}")))
    tf: Counter = Counter(t for a in articles for t in _tokens(f"{a.title} {a.text}"))
    term_set = {t.lower() for t in terms}
    themes = sorted((t for t, c in df.items() if c >= 2 and t not in term_set and not t.endswith("ed")),
                    key=lambda t: (-df[t], -tf[t]))
    return Entities(organisations=top(orgs), terms=top(terms), topics=themes[:6])


def extractive_report(articles: list[Article]) -> ReportDraft:
    return ReportDraft(summary=extractive_summary(articles), key_takeaways=extractive_takeaways(articles),
                       entities=extract_entities(articles))
