"""Logging: human-readable console output + structured JSON-lines file for analysis."""
from __future__ import annotations

import json
import logging
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

_CONFIGURED = False


class JsonLineFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "ts": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        extra = getattr(record, "data", None)
        if extra:
            payload.update(extra)
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


def setup_logging(log_dir: Path, level: int = logging.INFO) -> None:
    global _CONFIGURED
    if _CONFIGURED:
        return
    log_dir.mkdir(parents=True, exist_ok=True)
    root = logging.getLogger("report_agent")
    root.setLevel(level)
    root.propagate = False

    console = logging.StreamHandler()
    console.setFormatter(logging.Formatter("%(asctime)s | %(levelname)-7s | %(name)s | %(message)s", "%H:%M:%S"))
    root.addHandler(console)

    file_handler = logging.FileHandler(log_dir / "agent.jsonl", encoding="utf-8")
    file_handler.setFormatter(JsonLineFormatter())
    root.addHandler(file_handler)

    for noisy in ("httpx", "httpcore", "urllib3", "apscheduler"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
    _CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"report_agent.{name}")


def log_event(logger: logging.Logger, msg: str, **data) -> None:
    """Log a message with structured fields (they land as JSON keys in agent.jsonl)."""
    logger.info(msg + (" | " + ", ".join(f"{k}={v}" for k, v in data.items()) if data else ""),
                extra={"data": data})


@contextmanager
def timed(logger: logging.Logger, step: str, **data):
    """Time a graph node / step and log its duration."""
    start = time.perf_counter()
    try:
        yield
    finally:
        log_event(logger, f"step finished: {step}", step=step,
                  duration_ms=round((time.perf_counter() - start) * 1000, 1), **data)
