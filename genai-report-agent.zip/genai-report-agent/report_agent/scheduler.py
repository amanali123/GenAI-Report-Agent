"""Hourly scheduling with APScheduler.

`max_instances=1` + `coalesce=True` guarantee a slow run (e.g. a hanging site) never overlaps the
next one and missed ticks collapse into a single catch-up run.
"""
from __future__ import annotations

from datetime import datetime

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.interval import IntervalTrigger

from .config import Settings, get_settings
from .logging_setup import get_logger, log_event
from .report_graph import run_report_cycle

log = get_logger("scheduler")


def _job(settings: Settings, topics: list[str] | None) -> None:
    try:
        reports = run_report_cycle(topics, settings=settings)
        log_event(log, "scheduled run finished", reports=len(reports))
    except Exception:  # never let one failure kill the scheduler
        log.exception("scheduled run crashed")


def _add_job(scheduler, settings: Settings, topics: list[str] | None, minutes: int) -> None:
    scheduler.add_job(_job, IntervalTrigger(minutes=minutes), args=[settings, topics], id="hourly_report",
                      next_run_time=datetime.now(), max_instances=1, coalesce=True, replace_existing=True)
    log_event(log, "scheduler started", every_minutes=minutes, topics=topics or settings.topics)


def run_forever(topics: list[str] | None = None, minutes: int | None = None) -> None:
    """Blocking scheduler for the `schedule` CLI command (first run fires immediately)."""
    s = get_settings()
    sched = BlockingScheduler()
    _add_job(sched, s, topics, minutes or s.schedule_minutes)
    try:
        sched.start()
    except (KeyboardInterrupt, SystemExit):
        log.info("scheduler stopped")


def start_background(topics: list[str] | None = None, minutes: int | None = None) -> BackgroundScheduler:
    """Non-blocking scheduler used by the Streamlit app so reports refresh while users chat."""
    s = get_settings()
    sched = BackgroundScheduler()
    _add_job(sched, s, topics, minutes or s.schedule_minutes)
    sched.start()
    return sched
