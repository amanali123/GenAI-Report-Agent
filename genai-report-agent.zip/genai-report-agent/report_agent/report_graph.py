"""LangGraph workflow that turns fresh articles into an evaluated report.

    plan_collection ─► collect (ToolNode) ─► process ─┬─► summarise ─► evaluate ─┬─► save ─► END
                                                      │                  ▲        │
                                                      └─► END (no news)  └ revise ◄┘ (failed & budget left)
"""
from __future__ import annotations

import json
import re
import uuid
from datetime import datetime, timezone
from operator import add
from typing import Annotated, TypedDict

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, AnyMessage, ToolMessage
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode

from .config import SOURCES, Settings, get_settings
from .evaluation import evaluate_report
from .llm import get_chat_model, model_label
from .logging_setup import get_logger, log_event, timed
from .schemas import Article, EvalResult, Report, ReportDraft
from .sources import relevance_score
from .storage import ReportStore
from .summarise import extract_entities, extractive_report, format_notes, map_summaries, reduce_report, revise_report
from .tools import COLLECTION_TOOLS

log = get_logger("report_graph")
MIN_ARTICLES = 3  # below this, recent background articles are added for context


class ReportState(TypedDict, total=False):
    topic: str
    run_id: str
    messages: Annotated[list[AnyMessage], add_messages]   # tool-call channel for ToolNode
    articles: list[Article]
    notes: str
    draft: ReportDraft
    evaluation: EvalResult
    revisions: int
    report: Report
    status: str
    errors: Annotated[list[str], add]


def _ensure_entities(draft: ReportDraft, articles: list[Article]) -> ReportDraft:
    """If the model left out organisations/terms, fill them with the heuristic extractor (logged)."""
    e = draft.entities
    if not (e.organisations or e.terms):
        log_event(log, "entities missing from LLM output, using heuristic extraction")
        draft.entities = extract_entities(articles)
    return draft


def _title_key(title: str) -> str:
    return " ".join(sorted(re.findall(r"[a-z]{4,}", title.lower()))[:8])


def build_report_graph(settings: Settings | None = None, llm: BaseChatModel | None = None,
                       store: ReportStore | None = None, use_llm: bool = True):
    s = settings or get_settings()
    store = store or ReportStore(s.data_dir)
    if use_llm and llm is None:
        llm = get_chat_model(s)
    judge = llm if (llm is not None and s.llm_judge) else None

    # ---------------------------------------------------------------- nodes
    def plan_collection(state: ReportState) -> dict:
        """Emit one tool call per trusted source (deterministic plan: reproducible & cheap)."""
        topic, skip = state["topic"], sorted(store.seen_urls(state["topic"]))
        if s.source_mode == "fixtures":
            calls = [{"name": "load_sample_articles", "id": f"call_{uuid.uuid4().hex[:8]}",
                      "args": {"topic": topic, "batch": store.run_count() + 1, "skip_urls": skip}}]
        else:
            calls = [{"name": "fetch_source_articles", "id": f"call_{uuid.uuid4().hex[:8]}",
                      "args": {"source_name": src["name"], "topic": topic, "skip_urls": skip}}
                     for src in SOURCES]
        log_event(log, "collection planned", run_id=state["run_id"], topic=topic, tool_calls=len(calls),
                  mode=s.source_mode, already_seen=len(skip))
        return {"messages": [AIMessage(content="", tool_calls=calls)]}

    def process(state: ReportState) -> dict:
        """Parse tool results, merge sources, de-duplicate and rank by topical relevance."""
        with timed(log, "process", run_id=state["run_id"]):
            articles: list[Article] = []
            errors: list[str] = []
            for msg in state["messages"]:
                if not isinstance(msg, ToolMessage):
                    continue
                payload = json.loads(msg.content)
                if isinstance(payload, dict) and "error" in payload:
                    errors.append(payload["error"])
                    continue
                articles += [Article(**a) for a in payload]
            seen_urls, seen_titles, unique = set(), set(), []
            for a in articles:
                key = _title_key(a.title)
                if a.url in seen_urls or key in seen_titles or len(a.text) < 80:
                    continue
                seen_urls.add(a.url)
                seen_titles.add(key)
                unique.append(a)
            unique.sort(key=lambda a: -relevance_score(a, state["topic"]))
            unique = unique[: s.max_articles_per_topic]
            n_new = len(unique)
            # Context backfill: a single new article cannot support a 100-150 word synthesis without
            # padding (a hallucination risk), so recent already-reported articles are added as background.
            if 0 < n_new < MIN_ARTICLES:
                for row in store.recent_articles(state["topic"], MIN_ARTICLES - n_new, exclude=seen_urls):
                    row.pop("topic", None)
                    unique.append(Article(**{**row, "background": True}))
        log_event(log, "articles processed", run_id=state["run_id"], raw=len(articles), new=n_new,
                  background=len(unique) - n_new, source_errors=len(errors))
        status = "ok" if n_new else ("collection_failed" if errors and not articles else "no_new_articles")
        return {"articles": unique, "errors": errors, "status": status}

    def summarise(state: ReportState) -> dict:
        articles, topic = state["articles"], state["topic"]
        with timed(log, "summarise", run_id=state["run_id"], method=model_label(llm), articles=len(articles)):
            if llm is None:
                return {"draft": extractive_report(articles), "notes": "", "revisions": 0}
            notes = map_summaries(llm, articles, topic)
            kept = [(a, n) for a, n in zip(articles, notes) if "NOT_RELEVANT" not in n]
            if not kept:  # LLM judged everything off-topic: fall back to all articles
                kept = list(zip(articles, notes))
            arts, nts = zip(*kept)
            notes_text = format_notes(list(arts), list(nts))
            draft = _ensure_entities(reduce_report(llm, notes_text, topic), list(arts))
        return {"draft": draft, "notes": notes_text, "articles": list(arts), "revisions": 0}

    def evaluate(state: ReportState) -> dict:
        with timed(log, "evaluate", run_id=state["run_id"]):
            result = evaluate_report(state["draft"], state["articles"], state["topic"],
                                     judge=judge, source_notes=state.get("notes") or None)
        log_event(log, "report evaluated", run_id=state["run_id"], passed=result.passed, score=result.score,
                  revisions=state.get("revisions", 0), **{f"chk_{k}": v for k, v in result.checks.items()})
        return {"evaluation": result}

    def revise(state: ReportState) -> dict:
        with timed(log, "revise", run_id=state["run_id"], attempt=state.get("revisions", 0) + 1):
            draft = revise_report(llm, state["notes"], state["topic"], state["draft"], state["evaluation"].feedback)
            draft = _ensure_entities(draft, state["articles"])
        return {"draft": draft, "revisions": state.get("revisions", 0) + 1}

    def save(state: ReportState) -> dict:
        now = datetime.now(timezone.utc)
        slug = re.sub(r"[^a-z0-9]+", "-", state["topic"].lower()).strip("-")
        d = state["draft"]
        report = Report(
            id=f"{now:%Y%m%dT%H%M%SZ}_{slug}_{uuid.uuid4().hex[:4]}", topic=state["topic"], created_at=now.isoformat(timespec="microseconds"),
            summary=d.summary.strip(), key_takeaways=[t.strip() for t in d.key_takeaways][:5], entities=d.entities,
            sources=[{"title": a.title, "url": a.url, "source": a.source, "published": a.published,
                      "background": a.background} for a in state["articles"]],
            method=model_label(llm), evaluation=state.get("evaluation"), revisions=state.get("revisions", 0),
        )
        path = store.save_report(report)
        new_articles = [a for a in state["articles"] if not a.background]
        store.mark_seen(state["topic"], [a.url for a in new_articles])
        store.save_articles(state["topic"], new_articles)
        log_event(log, "report saved", run_id=state["run_id"], topic=state["topic"], path=str(path))
        return {"report": report, "status": "saved"}

    # ---------------------------------------------------------------- routing
    def after_process(state: ReportState) -> str:
        return "summarise" if state.get("status") == "ok" else END

    def after_evaluate(state: ReportState) -> str:
        ev = state["evaluation"]
        if not ev.passed and llm is not None and state.get("revisions", 0) < s.max_revisions:
            return "revise"
        return "save"

    g = StateGraph(ReportState)
    g.add_node("plan_collection", plan_collection)
    g.add_node("collect", ToolNode(COLLECTION_TOOLS))
    g.add_node("process", process)
    g.add_node("summarise", summarise)
    g.add_node("evaluate", evaluate)
    g.add_node("revise", revise)
    g.add_node("save", save)
    g.add_edge(START, "plan_collection")
    g.add_edge("plan_collection", "collect")
    g.add_edge("collect", "process")
    g.add_conditional_edges("process", after_process, {"summarise": "summarise", END: END})
    g.add_edge("summarise", "evaluate")
    g.add_conditional_edges("evaluate", after_evaluate, {"revise": "revise", "save": "save"})
    g.add_edge("revise", "evaluate")
    g.add_edge("save", END)
    return g.compile()


def run_report_cycle(topics: list[str] | None = None, settings: Settings | None = None,
                     use_llm: bool = True, print_reports: bool = True) -> list[Report]:
    """One scheduled tick: run the graph for each topic, persist reports, log a run summary."""
    s = settings or get_settings()
    store = ReportStore(s.data_dir)
    graph = build_report_graph(s, store=store, use_llm=use_llm)
    run_id = uuid.uuid4().hex[:10]
    started = datetime.now(timezone.utc)
    reports, outcome = [], {}
    for topic in topics or s.topics:
        try:
            final = graph.invoke({"topic": topic, "run_id": run_id, "messages": [], "errors": []})
        except Exception as exc:
            log.exception("report graph failed | topic=%s", topic)
            outcome[topic] = f"error: {exc}"
            continue
        outcome[topic] = final.get("status")
        if final.get("report"):
            reports.append(final["report"])
            if print_reports:
                print("\n" + final["report"].to_markdown())
        else:
            log_event(log, "no report produced", run_id=run_id, topic=topic, status=final.get("status"),
                      errors=final.get("errors"))
    store.record_run({"run_id": run_id, "started": started.isoformat(), "outcome": outcome,
                      "reports": [r.id for r in reports]})
    log_event(log, "cycle complete", run_id=run_id, reports=len(reports), outcome=outcome)
    return reports
