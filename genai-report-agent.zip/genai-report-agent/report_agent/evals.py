"""Offline evaluation harness: report quality (from saved reports) + chat behaviour (scripted cases).

Run: `python main.py eval`  → writes examples/eval_results.json and examples/eval_results.md
"""
from __future__ import annotations

import json
import re
import time
import uuid
from pathlib import Path

from .chat_graph import ChatSession
from .config import Settings, get_settings
from .logging_setup import get_logger, log_event
from .storage import ReportStore

log = get_logger("evals")

# Each case is a list of turns (multi-turn cases test conversational memory / follow-up rewriting).
# `expect_any`: at least one of these strings must appear in the answer (case-insensitive).
CHAT_CASES = [
    {"name": "vague overview", "turns": [
        {"q": "What's happening nowadays?", "intent": "overview", "min_topics": 2}]},
    {"name": "example from brief", "turns": [
        {"q": "What's new in AI today?", "intent": "topical", "expect_any": ["AI"]}]},
    {"name": "specific fact", "turns": [
        {"q": "Did the Monetary Policy Board change interest rates?", "intent": "topical",
         "expect_any": ["3.75"]}]},
    {"name": "follow-up resolution", "turns": [
        {"q": "What is happening with AI regulation?", "intent": "topical", "expect_any": ["AI"]},
        {"q": "What about the economy?", "intent": "followup", "expect_topic": "UK Economy"}]},
    {"name": "out of scope", "turns": [
        {"q": "Who won the Champions League final?", "intent": "topical", "expect_refusal": True}]},
    {"name": "small talk", "turns": [{"q": "hello", "intent": "smalltalk"}]},
]

REFUSAL_RE = re.compile(r"(don't|do not|doesn't|does not) (seem to )?(cover|have|mention|include)|not covered|"
                        r"no (information|reports?) (on|about)|isn't covered|can't find", re.IGNORECASE)


def evaluate_chat(settings: Settings | None = None, use_llm: bool = True) -> dict:
    s = settings or get_settings()
    results = []
    for case in CHAT_CASES:
        session = ChatSession(thread_id=f"eval-{uuid.uuid4().hex[:6]}", settings=s, use_llm=use_llm)
        for turn in case["turns"]:
            t0 = time.perf_counter()
            out = session.ask(turn["q"])
            latency = round((time.perf_counter() - t0) * 1000)
            ans = out["answer"]
            checks = {"intent_ok": out["intent"] == turn["intent"]}
            if "expect_any" in turn:
                checks["content_ok"] = any(e.lower() in ans.lower() for e in turn["expect_any"])
            if turn.get("intent") in {"topical", "overview", "followup"} and not turn.get("expect_refusal"):
                checks["cited"] = bool(re.search(r"\[R\d+\]", ans))
            if "min_topics" in turn:
                checks["topics_covered"] = len({c["topic"] for c in out["citations"]}) >= turn["min_topics"]
            if "expect_topic" in turn:
                checks["topic_resolved"] = any(c["topic"] == turn["expect_topic"] for c in out["citations"][:2])
            if turn.get("expect_refusal"):
                checks["refused_ok"] = bool(REFUSAL_RE.search(ans))
            results.append({"case": case["name"], "question": turn["q"], "intent": out["intent"],
                            "rewritten_query": out["query"], "answer": ans, "latency_ms": latency,
                            "checks": checks, "passed": all(checks.values())})
            log_event(log, "chat eval turn", case=case["name"], passed=all(checks.values()), latency_ms=latency)
    passed = sum(r["passed"] for r in results)
    return {"turns": len(results), "passed": passed, "pass_rate": round(passed / len(results), 2),
            "results": results}


def evaluate_reports(settings: Settings | None = None) -> dict:
    s = settings or get_settings()
    reports = ReportStore(s.data_dir).list_reports()
    rows = [{"id": r.id, "topic": r.topic, "method": r.method, "passed": r.evaluation.passed,
             "score": r.evaluation.score, "revisions": r.revisions,
             "words": r.evaluation.checks.get("summary_word_count"),
             "takeaways": r.evaluation.checks.get("takeaways_count")} for r in reports if r.evaluation]
    n = len(rows) or 1
    return {"reports": len(rows), "pass_rate": round(sum(r["passed"] for r in rows) / n, 2),
            "mean_score": round(sum(r["score"] for r in rows) / n, 3), "rows": rows}


def run_all(out_dir: Path, settings: Settings | None = None, use_llm: bool = True) -> dict:
    s = settings or get_settings()
    out_dir.mkdir(parents=True, exist_ok=True)
    result = {"reports": evaluate_reports(s), "chat": evaluate_chat(s, use_llm=use_llm)}
    (out_dir / "eval_results.json").write_text(json.dumps(result, indent=2), encoding="utf-8")

    md = ["# Evaluation results", "", "## Reports",
          f"{result['reports']['reports']} reports · pass rate **{result['reports']['pass_rate']:.0%}** · "
          f"mean score **{result['reports']['mean_score']}**", "",
          "| report | method | words | takeaways | revisions | score | passed |", "|---|---|---|---|---|---|---|"]
    md += [f"| {r['id']} | {r['method']} | {r['words']} | {r['takeaways']} | {r['revisions']} | {r['score']} | "
           f"{'✅' if r['passed'] else '❌'} |" for r in result["reports"]["rows"]]
    c = result["chat"]
    md += ["", "## Chat", f"{c['turns']} turns · pass rate **{c['pass_rate']:.0%}**", "",
           "| case | question | intent | checks | latency | passed |", "|---|---|---|---|---|---|"]
    md += [f"| {r['case']} | {r['question']} | {r['intent']} | "
           f"{', '.join(f'{k}={v}' for k, v in r['checks'].items())} | {r['latency_ms']} ms | "
           f"{'✅' if r['passed'] else '❌'} |" for r in c["results"]]
    (out_dir / "eval_results.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    return result
