"""Typed data models shared by the pipeline, the chat agent and the evaluators."""
from __future__ import annotations

from pydantic import BaseModel, Field


class Article(BaseModel):
    url: str
    title: str
    source: str
    published: str | None = None
    summary: str = ""          # feed description / teaser
    text: str = ""             # cleaned full text (may fall back to summary)
    background: bool = False   # True = previously reported article reused for context


class Entities(BaseModel):
    organisations: list[str] = Field(default_factory=list, description="Organisations, companies, public bodies")
    terms: list[str] = Field(default_factory=list, description="Technical or policy terms, laws, products")
    topics: list[str] = Field(default_factory=list, description="Broad themes covered")


class ReportDraft(BaseModel):
    """What the LLM is asked to produce (structured output)."""
    summary: str = Field(description="One paragraph, 100-150 words, synthesising all articles")
    key_takeaways: list[str] = Field(description="3-5 short, distinct, factual takeaways")
    # Defaults make parsing tolerant: some models occasionally omit a field; the graph backfills it.
    entities: Entities = Field(default_factory=Entities,
                               description="Organisations, terms and topics mentioned in the notes (always include)")


class EvalResult(BaseModel):
    passed: bool
    score: float                       # 0..1 aggregate of the checks
    checks: dict[str, bool | float | int | str]
    feedback: list[str] = Field(default_factory=list)


class Report(BaseModel):
    id: str
    topic: str
    created_at: str                    # ISO-8601 UTC
    summary: str
    key_takeaways: list[str]
    entities: Entities
    sources: list[dict]                # [{title, url, source, published}]
    method: str                        # e.g. "llm:anthropic/claude-sonnet-5-5" or "extractive"
    evaluation: EvalResult | None = None
    revisions: int = 0

    def to_markdown(self) -> str:
        lines = [
            f"# {self.topic} — report",
            f"_Generated {self.created_at} · method: {self.method} · {len(self.sources)} sources_",
            "",
            "## Summary",
            self.summary,
            "",
            "## Key takeaways",
            *[f"- {t}" for t in self.key_takeaways],
            "",
            "## Mentioned organisations, terms and topics",
            f"- **Organisations:** {', '.join(self.entities.organisations) or '—'}",
            f"- **Terms:** {', '.join(self.entities.terms) or '—'}",
            f"- **Topics:** {', '.join(self.entities.topics) or '—'}",
            "",
            "## Sources",
            *[f"{i}. [{s['title']}]({s['url']}) — {s['source']}{' _(background)_' if s.get('background') else ''}"
              for i, s in enumerate(self.sources, 1)],
        ]
        if self.evaluation:
            e = self.evaluation
            lines += ["", "## Evaluation",
                      f"- passed: **{e.passed}** · score: **{e.score:.2f}** · revisions: {self.revisions}",
                      *[f"- {k}: {v}" for k, v in e.checks.items()]]
        return "\n".join(lines) + "\n"
