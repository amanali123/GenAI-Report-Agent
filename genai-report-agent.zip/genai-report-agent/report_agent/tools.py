"""LangChain tools used by the LangGraph pipeline (executed through `langgraph.prebuilt.ToolNode`).

The pipeline never calls a website or an LLM vendor's HTTP API directly from graph
logic: collection is expressed as tool calls and executed by LangGraph's ToolNode,
and generation goes through LangChain chat-model interfaces.
"""
from __future__ import annotations

import json
from concurrent.futures import ThreadPoolExecutor

from langchain_core.tools import tool

from .config import SOURCES, get_settings
from .logging_setup import get_logger, log_event
from .sources import fetch_article, fetch_feed, filter_relevant, load_fixture_articles

log = get_logger("tools")


@tool
def fetch_source_articles(source_name: str, topic: str, skip_urls: list[str] | None = None) -> str:
    """Fetch the newest articles about `topic` from one trusted source (BBC News feed or GOV.UK search feed).

    Discovers items from the source's feed, keeps those relevant to the topic, skips URLs already
    processed, scrapes and cleans the full article text. Returns a JSON list of articles.
    """
    s = get_settings()
    source = next((src for src in SOURCES if src["name"] == source_name), None)
    if source is None:
        return json.dumps({"error": f"unknown source {source_name!r}"})
    skip = set(skip_urls or [])
    try:
        items = fetch_feed(source, topic=topic, timeout=s.request_timeout, limit=s.max_feed_items)
    except Exception as exc:  # network/parse errors are reported to the graph, not raised
        log.warning("feed failed | source=%s err=%s", source_name, exc)
        return json.dumps({"error": f"{source_name}: {exc}"})

    candidates = [a for a in filter_relevant(items, topic) if a.url not in skip][: s.max_articles_per_topic]
    with ThreadPoolExecutor(max_workers=4) as pool:
        articles = list(pool.map(lambda a: fetch_article(a, s.request_timeout, s.max_chars_per_article), candidates))
    log_event(log, "source scraped", source=source_name, topic=topic, feed_items=len(items),
              relevant_new=len(articles))
    return json.dumps([a.model_dump() for a in articles])


@tool
def load_sample_articles(topic: str, batch: int = 1, skip_urls: list[str] | None = None) -> str:
    """Offline mode: load bundled sample articles (simulating feeds) relevant to `topic`, up to `batch`."""
    s = get_settings()
    skip = set(skip_urls or [])
    arts = [a for a in filter_relevant(load_fixture_articles(s.fixtures_dir, batch), topic) if a.url not in skip]
    log_event(log, "fixtures loaded", topic=topic, batch=batch, relevant_new=len(arts))
    return json.dumps([a.model_dump() for a in arts[: s.max_articles_per_topic]])


COLLECTION_TOOLS = [fetch_source_articles, load_sample_articles]
