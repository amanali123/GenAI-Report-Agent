"""Conversational agent grounded in the latest reports (LangGraph + MemorySaver).

    analyse ─► retrieve ─► respond
      │  intent: overview (vague "what's happening?") | topical | followup | smalltalk
      │  follow-ups are rewritten into standalone queries using conversation history
      └─ retrieve: overview → latest report per topic; otherwise BM25 + recency over report chunks

Context engineering choices (see WRITEUP.md):
  * the context window holds *reports*, not raw articles — dense, pre-validated, cheap;
  * every context block carries its timestamp + an [R#] id so answers can cite and date claims;
  * history is trimmed to the last N turns; older turns are not needed once the query is rewritten;
  * explicit "not covered" behaviour when retrieval confidence is low (no answer from parametric memory).
"""
from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import Annotated, TypedDict

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, AnyMessage, HumanMessage, SystemMessage
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.graph.message import add_messages

from .config import TOPIC_KEYWORDS, Settings, get_settings
from .llm import get_chat_model
from .logging_setup import get_logger, log_event, timed
from .retrieval import Chunk, build_chunks, search
from .schemas import Report
from .storage import ReportStore

log = get_logger("chat")

VAGUE_RE = re.compile(
    r"\b(what'?s|what is|whats)\s+(happening|new|going on|up|the latest)|\b(any|latest|recent)\s+(news|updates?)|"
    r"\bnowadays\b|\bthese days\b|\bupdate me\b|\bcatch me up\b|\bbrief me\b|\bwhat did i miss\b|\bheadlines\b|"
    r"\bsummar(y|ise|ize) (everything|it all|the news)\b", re.IGNORECASE)
SMALLTALK_RE = re.compile(r"^\s*(hi|hello|hey|thanks|thank you|cheers|good (morning|afternoon|evening)|bye)\b[!. ]*$",
                          re.IGNORECASE)
FOLLOWUP_RE = re.compile(r"^\s*(and|what about|how about|why|so|tell me more|more on|what else|elaborate|"
                         r"explain|go on)\b|\b(it|that|this|they|them|those|he|she|its|their)\b", re.IGNORECASE)
TOPIC_SWITCH_RE = re.compile(r"^\s*(what about|how about|and what about|and)\b", re.IGNORECASE)
_FOLLOWUP_WORDS = {"what", "about", "how", "and", "tell", "more", "else", "why", "explain", "elaborate"}
MIN_COVERAGE = 0.5  # share of query terms the best chunk must contain; below this → "not covered"

SYSTEM_PROMPT = """You are the News Briefing Assistant. You answer questions using ONLY the briefing reports in CONTEXT, \
which were generated automatically from trusted sources (BBC News, GOV.UK). Current time: {now}.

Rules:
- Ground every factual statement in CONTEXT and cite it with its id, e.g. [R1]. Never use outside knowledge for news.
- Mention how recent the information is (each block has a timestamp).
- If CONTEXT does not answer the question, say so plainly, then offer what the reports DO cover ({topics}).
- For broad questions ("what's happening?"), give a short overview across topics, most important first.
- Be concise: 3-6 sentences or a short bullet list."""

REWRITE_PROMPT = ChatPromptTemplate.from_messages([
    ("system", "Rewrite the user's last message as a standalone search query about news, resolving pronouns "
               "and references using the conversation. Output only the query."),
    ("human", "Conversation:\n{history}\n\nLast message: {question}"),
])


class ChatState(TypedDict, total=False):
    messages: Annotated[list[AnyMessage], add_messages]
    query: str
    intent: str
    topic: str | None
    context: str
    citations: list[dict]
    top_score: float


def detect_topic(text: str) -> str | None:
    text = text.lower()
    scores = {t: sum(bool(re.search(rf"\b{re.escape(k)}\b", text)) for k in kws) for t, kws in TOPIC_KEYWORDS.items()}
    best = max(scores, key=scores.get)
    return best if scores[best] > 0 else None


def _content_words(text: str) -> list[str]:
    return [w for w in re.findall(r"[a-z]{2,}", text.lower()) if w not in _FOLLOWUP_WORDS
            and w not in {"the", "a", "an", "it", "that", "this", "they", "them", "those", "on", "with", "of", "to"}]


def _fmt_time(iso: str) -> str:
    return datetime.fromisoformat(iso).strftime("%d %b %Y %H:%M UTC")


def build_chat_graph(settings: Settings | None = None, llm: BaseChatModel | None = None, use_llm: bool = True,
                     store: ReportStore | None = None, checkpointer=None):
    s = settings or get_settings()
    store = store or ReportStore(s.data_dir)
    if use_llm and llm is None:
        llm = get_chat_model(s)

    # ---------------------------------------------------------------- analyse
    def analyse(state: ChatState) -> dict:
        msgs = state["messages"]
        question = msgs[-1].content
        history = [m for m in msgs[:-1] if isinstance(m, (HumanMessage, AIMessage))]
        if SMALLTALK_RE.match(question):
            intent = "smalltalk"
        elif VAGUE_RE.search(question) and not detect_topic(question):
            intent = "overview"
        elif history and (FOLLOWUP_RE.search(question) and len(question.split()) <= 12):
            intent = "followup"
        else:
            intent = "topical"

        query = question
        if intent == "followup":
            prev_q = next((m.content for m in reversed(history) if isinstance(m, HumanMessage)), "")
            if llm is not None:
                hist = "\n".join(f"{type(m).__name__[:-7]}: {m.content[:300]}" for m in history[-4:])
                query = (REWRITE_PROMPT | llm | StrOutputParser()).invoke({"history": hist, "question": question})
            elif TOPIC_SWITCH_RE.match(question) and _content_words(question):
                query = question  # "what about the economy?" introduces its own subject: don't drag the old one
            else:  # heuristic rewrite: "why?" / "tell me more" inherit the previous question's subject
                query = f"{question} {prev_q}"
            if VAGUE_RE.search(prev_q) and not detect_topic(question):
                intent = "overview"
        topic = detect_topic(query)
        log_event(log, "query analysed", intent=intent, topic=topic, query=query[:120])
        return {"query": query.strip(), "intent": intent, "topic": topic}

    # ---------------------------------------------------------------- retrieve
    def retrieve(state: ChatState) -> dict:
        with timed(log, "retrieve", intent=state["intent"]):
            if state["intent"] == "smalltalk":
                return {"context": "", "citations": [], "top_score": 0.0}
            reports = store.list_reports(limit=s.chat_reports_in_context * 3)
            if not reports:
                return {"context": "", "citations": [], "top_score": 0.0}
            if state["intent"] == "overview":
                selected = store.latest_per_topic()[: s.chat_reports_in_context]
                hits: list[Chunk] = []
                top = 1.0
            else:
                chunks = build_chunks(reports, store)
                hits = search(chunks, state["query"], k=8, topic=state.get("topic"))
                # confidence = best chunk's coverage of the query terms (BM25 scores are not comparable
                # across queries, coverage is), ties broken by BM25 rank
                top = max((h.coverage for h in hits), default=0.0)
                ids = list(dict.fromkeys(h.report_id for h in hits))[:4]
                by_id = {r.id: r for r in reports}
                selected = [by_id[i] for i in ids]
                if top < MIN_COVERAGE:  # low confidence: still give the model the latest reports to say what IS covered
                    selected = store.latest_per_topic()[:3]

            blocks, cites = [], []
            for n, r in enumerate(selected, 1):
                rid = f"R{n}"
                rel = [h.text for h in hits if h.report_id == r.id and h.kind == "article"][:3]
                blocks.append(
                    f"[{rid}] Topic: {r.topic} | generated {_fmt_time(r.created_at)}\n"
                    f"Summary: {r.summary}\nKey takeaways:\n" + "\n".join(f"- {t}" for t in r.key_takeaways) +
                    (("\nRelevant article excerpts:\n" + "\n".join(f"- {t}" for t in rel)) if rel else "") +
                    "\nSources: " + "; ".join(src["title"] for src in r.sources[:6]))
                cites.append({"id": rid, "report_id": r.id, "topic": r.topic, "created_at": r.created_at,
                              "sources": r.sources})
        log_event(log, "context built", reports=len(selected), top_score=top,
                  context_chars=sum(map(len, blocks)))
        return {"context": "\n\n".join(blocks), "citations": cites, "top_score": top}

    # ---------------------------------------------------------------- respond
    def respond(state: ChatState) -> dict:
        topics = ", ".join(sorted({r.topic for r in store.latest_per_topic()})) or "no topics yet"
        with timed(log, "respond", intent=state["intent"], llm=llm is not None):
            if not state.get("citations") and state["intent"] != "smalltalk":
                answer = ("I don't have any reports yet. Generate one with `python main.py report` "
                          "(or wait for the hourly run), then ask again.")
            elif llm is None:
                answer = _offline_answer(state, topics)
            elif state["intent"] == "smalltalk":
                answer = (llm | StrOutputParser()).invoke([
                    SystemMessage(f"You are a friendly news briefing assistant covering: {topics}. Reply in one "
                                  "or two sentences and invite a question."), state["messages"][-1]])
            else:
                history = [m for m in state["messages"][:-1] if isinstance(m, (HumanMessage, AIMessage))]
                history = history[-2 * s.chat_history_turns:]
                low_conf = state["intent"] != "overview" and state.get("top_score", 0) < MIN_COVERAGE
                system = SYSTEM_PROMPT.format(now=datetime.now(timezone.utc).strftime("%d %b %Y %H:%M UTC"),
                                              topics=topics)
                user = (f"CONTEXT:\n{state['context']}\n\n"
                        + ("NOTE: retrieval found no strong match; the question may not be covered.\n\n" if low_conf else "")
                        + f"QUESTION ({state['intent']}): {state['messages'][-1].content}")
                answer = (llm | StrOutputParser()).invoke([SystemMessage(system), *history, HumanMessage(user)])
        log_event(log, "answer generated", intent=state["intent"], chars=len(answer),
                  cited=sorted(set(re.findall(r"\[R\d+\]", answer))))
        return {"messages": [AIMessage(content=answer)]}

    def _offline_answer(state: ChatState, topics: str) -> str:
        """Retrieval-only answer used when no LLM is configured (keeps the demo key-free)."""
        cites = state["citations"]
        if state["intent"] == "smalltalk":
            return f"Hi! I summarise the latest news on {topics}. Try asking “What’s happening nowadays?”"
        if state["intent"] == "overview":
            lines, shown = ["Here's the latest across the topics I track:"], set()
            for c in cites:
                r = store_report(c["report_id"])
                fresh = [t for t in r.key_takeaways if t not in shown][:3]  # topics overlap: avoid repeats
                shown.update(fresh)
                if fresh:
                    lines.append(f"\n**{r.topic}** (report {_fmt_time(r.created_at)}) [{c['id']}]")
                    lines += [f"- {t}" for t in fresh]
            return "\n".join(lines)
        if state.get("top_score", 0) < MIN_COVERAGE:
            return (f"The latest reports don't seem to cover that. They currently cover: {topics}. "
                    "Try asking about one of those, or “What’s happening nowadays?”")
        q_tokens = set(re.findall(r"[a-z]{4,}", state["query"].lower()))
        lines = []
        for c in cites[:2]:
            r = store_report(c["report_id"])
            ranked = sorted(r.key_takeaways + re.split(r"(?<=[.!?])\s+", r.summary),
                            key=lambda t: -len(q_tokens & set(re.findall(r"[a-z]{4,}", t.lower()))))
            picked = list(dict.fromkeys(ranked))[:2]
            lines.append(f"From the {r.topic} report ({_fmt_time(r.created_at)}) [{c['id']}]:")
            lines += [f"- {p}" for p in picked]
        return "\n".join(lines)

    _cache: dict[str, Report] = {}

    def store_report(report_id: str) -> Report:
        if report_id not in _cache:
            _cache.update({r.id: r for r in store.list_reports()})
        return _cache[report_id]

    g = StateGraph(ChatState)
    g.add_node("analyse", analyse)
    g.add_node("retrieve", retrieve)
    g.add_node("respond", respond)
    g.add_edge(START, "analyse")
    g.add_edge("analyse", "retrieve")
    g.add_edge("retrieve", "respond")
    g.add_edge("respond", END)
    return g.compile(checkpointer=checkpointer or MemorySaver())


class ChatSession:
    """Small convenience wrapper used by the CLI, Streamlit app and evaluations."""

    def __init__(self, thread_id: str = "default", **kwargs):
        self.graph = build_chat_graph(**kwargs)
        self.config = {"configurable": {"thread_id": thread_id}}

    def ask(self, question: str) -> dict:
        out = self.graph.invoke({"messages": [HumanMessage(content=question)]}, self.config)
        return {"answer": out["messages"][-1].content, "intent": out.get("intent"), "query": out.get("query"),
                "citations": out.get("citations", []), "top_score": out.get("top_score")}
