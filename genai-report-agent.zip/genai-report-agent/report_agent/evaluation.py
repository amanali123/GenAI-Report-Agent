"""Report evaluation: cheap deterministic checks on every run + optional LLM-as-judge.

Deterministic checks catch format violations and the most damaging hallucinations
(invented numbers / entities) at zero cost; their feedback strings drive the
graph's revise loop. The LLM judge adds a semantic faithfulness/relevance score.
"""
from __future__ import annotations

import re

from langchain_core.language_models import BaseChatModel
from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field

from .llm import structured
from .schemas import Article, EvalResult, ReportDraft
from .summarise import _tokens, _too_similar

WORD_MIN, WORD_MAX = 100, 150
TAKEAWAYS_MIN, TAKEAWAYS_MAX = 3, 5

_NUM_RE = re.compile(r"\b\d[\d,.]*%?")


def _norm_num(n: str) -> str:
    return n.rstrip(".,").replace(",", "")


def _numbers(text: str) -> set[str]:
    return {_norm_num(n) for n in _NUM_RE.findall(text) if _norm_num(n)}


class JudgeVerdict(BaseModel):
    faithfulness: int = Field(ge=1, le=5, description="5 = every claim is supported by the sources")
    relevance: int = Field(ge=1, le=5, description="5 = fully about the topic and covers the main stories")
    issues: list[str] = Field(default_factory=list, description="Specific unsupported or off-topic claims")


JUDGE_PROMPT = ChatPromptTemplate.from_messages([
    ("system", "You are a strict fact-checking evaluator. Compare the REPORT to the SOURCE NOTES about "
               "'{topic}'. Score faithfulness and relevance from 1-5 and list concrete issues."),
    ("human", "SOURCE NOTES:\n{sources}\n\nREPORT:\n{report}"),
])


def evaluate_report(draft: ReportDraft, articles: list[Article], topic: str,
                    judge: BaseChatModel | None = None, source_notes: str | None = None) -> EvalResult:
    source_text = " ".join(f"{a.title} {a.summary} {a.text}" for a in articles)
    source_lower = source_text.lower()
    src_tokens = set(_tokens(source_text))
    generated = draft.summary + " " + " ".join(draft.key_takeaways)

    checks: dict = {}
    feedback: list[str] = []

    # 1. length window
    wc = len(draft.summary.split())
    checks["summary_word_count"] = wc
    checks["summary_length_ok"] = WORD_MIN <= wc <= WORD_MAX
    if not checks["summary_length_ok"]:
        feedback.append(f"Summary has {wc} words; it must be between {WORD_MIN} and {WORD_MAX} words.")

    # 2. takeaways count + distinctness
    n_tk = len(draft.key_takeaways)
    checks["takeaways_count"] = n_tk
    checks["takeaways_count_ok"] = TAKEAWAYS_MIN <= n_tk <= TAKEAWAYS_MAX
    if not checks["takeaways_count_ok"]:
        feedback.append(f"Provide {TAKEAWAYS_MIN}-{TAKEAWAYS_MAX} key takeaways (currently {n_tk}).")
    dupes = sum(1 for i, a in enumerate(draft.key_takeaways) for b in draft.key_takeaways[i + 1:]
                if _too_similar(a, b, 0.7))
    checks["takeaways_distinct"] = dupes == 0
    if dupes:
        feedback.append("Some key takeaways repeat each other; make each one distinct.")

    # 3. numeric hallucination: every number in the output must exist in the sources
    src_nums = _numbers(source_text)
    unsupported = sorted(n for n in _numbers(generated) if n not in src_nums)
    checks["numbers_grounded"] = not unsupported
    if unsupported:
        feedback.append(f"These numbers do not appear in the sources, remove or correct them: {unsupported}.")

    # 4. entity grounding: mentioned entities should literally appear in the sources
    ents = draft.entities.organisations + draft.entities.terms
    grounded = [e for e in ents if e.lower() in source_lower]
    ratio = len(grounded) / len(ents) if ents else 0.0
    checks["entity_grounding"] = round(ratio, 2)
    if ratio < 0.7:
        missing = [e for e in ents if e not in grounded][:5]
        feedback.append(f"Entities not found verbatim in sources: {missing}. Use names exactly as in the articles.")
    if not draft.entities.organisations:
        feedback.append("List the organisations mentioned in the articles.")

    # 5. lexical faithfulness proxy: share of content words in the summary that occur in sources
    sum_tokens = _tokens(draft.summary)
    lex = sum(t in src_tokens for t in sum_tokens) / len(sum_tokens) if sum_tokens else 0.0
    checks["lexical_support"] = round(lex, 2)

    # 6. coverage: how many articles are reflected (≥2 distinctive title words in the output)
    gen_tokens = set(_tokens(generated))
    covered = sum(1 for a in articles if len(set(_tokens(a.title)) & gen_tokens) >= 2)
    checks["article_coverage"] = round(covered / len(articles), 2) if articles else 0.0

    # 7. optional LLM-as-judge
    if judge is not None:
        try:
            verdict: JudgeVerdict = (JUDGE_PROMPT | structured(judge, JudgeVerdict)).invoke({
                "topic": topic, "sources": source_notes or source_text[:12000],
                "report": draft.model_dump_json(indent=2)})
            checks["judge_faithfulness"] = verdict.faithfulness
            checks["judge_relevance"] = verdict.relevance
            if verdict.faithfulness < 4:
                feedback.append("Judge found unsupported claims: " + "; ".join(verdict.issues[:3]))
        except Exception as exc:  # judge failure must never break reporting
            checks["judge_error"] = str(exc)[:120]

    hard = ["summary_length_ok", "takeaways_count_ok", "numbers_grounded"]
    passed = all(checks[k] for k in hard) and ratio >= 0.7 and checks.get("judge_faithfulness", 5) >= 4
    soft = [float(checks[k]) for k in hard + ["takeaways_distinct"]] + [ratio, lex, checks["article_coverage"]]
    if "judge_faithfulness" in checks:
        soft += [checks["judge_faithfulness"] / 5, checks["judge_relevance"] / 5]
    return EvalResult(passed=passed, score=round(sum(soft) / len(soft), 3), checks=checks, feedback=feedback)
