"""Central configuration, read from environment variables (or a .env file)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

try:  # optional dependency
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:  # pragma: no cover
    pass

PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _env_bool(name: str, default: bool) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}


# Topic -> keywords used for relevance filtering of scraped articles.
# A custom topic not listed here falls back to the words of its own name.
TOPIC_KEYWORDS: dict[str, list[str]] = {
    "AI Regulation": [
        "ai", "artificial intelligence", "regulation", "regulator", "safety", "bill",
        "legislation", "act", "model", "frontier", "chatbot", "deepfake", "copyright",
        "algorithm", "online safety", "ofcom", "governance",
    ],
    "Technology Updates": [
        "technology", "tech", "software", "app", "chip", "semiconductor", "cyber",
        "smartphone", "data", "cloud", "start-up", "startup", "broadband", "5g",
        "quantum", "robot", "digital", "ai",
    ],
    "UK Economy": [
        "economy", "inflation", "interest rate", "bank of england", "gdp", "growth",
        "budget", "treasury", "tax", "wages", "unemployment", "jobs", "pound",
        "borrowing", "recession", "prices", "ons",
    ],
}

# Predefined trusted sources. `kind` selects the parser.
# GOV.UK exposes Atom feeds for any search, so a topic keyword can be passed through.
SOURCES: list[dict] = [
    {"name": "BBC News – Technology", "kind": "rss",
     "url": "https://feeds.bbci.co.uk/news/technology/rss.xml"},
    {"name": "BBC News – Business", "kind": "rss",
     "url": "https://feeds.bbci.co.uk/news/business/rss.xml"},
    {"name": "BBC News – UK Politics", "kind": "rss",
     "url": "https://feeds.bbci.co.uk/news/politics/rss.xml"},
    {"name": "GOV.UK – News and communications", "kind": "atom",
     "url": "https://www.gov.uk/search/news-and-communications.atom"},
]


@dataclass
class Settings:
    # --- LLM ---------------------------------------------------------------
    llm_provider: str = field(default_factory=lambda: os.getenv("LLM_PROVIDER", "auto"))  # auto|anthropic|openai|ollama|offline
    llm_model: str | None = field(default_factory=lambda: os.getenv("LLM_MODEL") or None)
    llm_temperature: float = field(default_factory=lambda: float(os.getenv("LLM_TEMPERATURE", "0.2")))
    llm_judge: bool = field(default_factory=lambda: _env_bool("EVAL_LLM_JUDGE", True))  # LLM-as-judge (only when an LLM is set)

    # --- Data collection -----------------------------------------------------
    source_mode: str = field(default_factory=lambda: os.getenv("SOURCE_MODE", "live"))  # live | fixtures
    topics: list[str] = field(default_factory=lambda: [
        t.strip() for t in os.getenv("TOPICS", "AI Regulation,Technology Updates,UK Economy").split(",")
        if t.strip()
    ])
    max_articles_per_topic: int = field(default_factory=lambda: int(os.getenv("MAX_ARTICLES_PER_TOPIC", "8")))
    max_feed_items: int = field(default_factory=lambda: int(os.getenv("MAX_FEED_ITEMS", "25")))
    request_timeout: int = field(default_factory=lambda: int(os.getenv("REQUEST_TIMEOUT", "15")))
    max_chars_per_article: int = field(default_factory=lambda: int(os.getenv("MAX_CHARS_PER_ARTICLE", "6000")))

    # --- Reporting -------------------------------------------------------------
    schedule_minutes: int = field(default_factory=lambda: int(os.getenv("SCHEDULE_MINUTES", "60")))
    max_revisions: int = field(default_factory=lambda: int(os.getenv("MAX_REVISIONS", "2")))

    # --- Chat ----------------------------------------------------------------
    chat_reports_in_context: int = field(default_factory=lambda: int(os.getenv("CHAT_REPORTS_IN_CONTEXT", "6")))
    chat_history_turns: int = field(default_factory=lambda: int(os.getenv("CHAT_HISTORY_TURNS", "6")))

    # --- Paths ---------------------------------------------------------------
    data_dir: Path = field(default_factory=lambda: Path(os.getenv("DATA_DIR", PROJECT_ROOT / "data")))
    log_dir: Path = field(default_factory=lambda: Path(os.getenv("LOG_DIR", PROJECT_ROOT / "logs")))
    fixtures_dir: Path = field(default_factory=lambda: PROJECT_ROOT / "fixtures")

    @property
    def reports_dir(self) -> Path:
        return self.data_dir / "reports"


def get_settings() -> Settings:
    """Fresh settings each call so tests / CLI flags can override env vars."""
    return Settings()
