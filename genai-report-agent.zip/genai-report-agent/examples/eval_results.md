# Evaluation results

## Reports
8 reports · pass rate **100%** · mean score **0.972**

| report | method | words | takeaways | revisions | score | passed |
|---|---|---|---|---|---|---|
| 20261101T233106Z_uk-economy_2107 | llm:anthropic/claude-sonnet-5-5 | 130 | 5 | 0 | 0.901 | ✅ |
| 20261030T115019Z_technology-updates_c57e | llm:anthropic/claude-sonnet-5-5 | 133 | 5 | 0 | 0.907 | ✅ |
| 20261029T120030Z_uk-economy_729c | extractive | 101 | 3 | 0 | 1.0 | ✅ |
| 20261029T120030Z_technology-updates_34db | extractive | 101 | 5 | 0 | 1.0 | ✅ |
| 20261029T120030Z_ai-regulation_0f16 | extractive | 114 | 4 | 0 | 1.0 | ✅ |
| 20261029T120030Z_uk-economy_3cc3 | extractive | 107 | 4 | 0 | 1.0 | ✅ |
| 20261029T120030Z_technology-updates_5e60 | extractive | 106 | 5 | 0 | 0.964 | ✅ |
| 20261029T120030Z_ai-regulation_e335 | extractive | 107 | 4 | 0 | 1.0 | ✅ |

## Chat
7 turns · pass rate **86%**

| case | question | intent | checks | latency | passed |
|---|---|---|---|---|---|
| vague overview | What's happening nowadays? | overview | intent_ok=True, cited=True, topics_covered=True | 4422 ms | ✅ |
| example from brief | What's new in AI today? | topical | intent_ok=True, content_ok=True, cited=True | 4542 ms | ✅ |
| specific fact | Did the Monetary Policy Board change interest rates? | topical | intent_ok=True, content_ok=True, cited=True | 2234 ms | ✅ |
| follow-up resolution | What is happening with AI regulation? | topical | intent_ok=True, content_ok=True, cited=True | 3350 ms | ✅ |
| follow-up resolution | What about the economy? | followup | intent_ok=True, cited=True, topic_resolved=False | 10035 ms | ❌ |
| out of scope | Who won the Champions League final? | topical | intent_ok=True, refused_ok=True | 2718 ms | ✅ |
| small talk | hello | smalltalk | intent_ok=True | 1503 ms | ✅ |
