# Technology Updates — report
_Generated 2026-10-29T11:15:32.250511+00:00 · method: extractive · 8 sources_

## Summary
Meridian AI has signed a licensing agreement with the Publishers Alliance allowing it to train its chatbot on archived news articles. A trial quantum communications network has successfully linked Bristol, Cambridge and London. The Office for AI Standards (OAIS) has opened a 12-week consultation on mandatory pre-deployment safety testing for frontier AI models. High street retailer Larkfield has said a cyber attack forced it to suspend online orders for two days. The AI Liability Bill passed its second reading in Parliament by 312 votes to 201. The Online Safety Commission has published guidance requiring AI chatbot providers to assess the risks their services pose to children.

## Key takeaways
- The Office for AI Standards (OAIS) has opened a 12-week consultation on mandatory pre-deployment safety testing for frontier AI models.
- The Online Safety Commission has published guidance requiring AI chatbot providers to assess the risks their services pose to children.
- Meridian AI has signed a licensing agreement with the Publishers Alliance allowing it to train its chatbot on archived news articles.
- A trial quantum communications network has successfully linked Bristol, Cambridge and London.
- The AI Liability Bill passed its second reading in Parliament by 312 votes to 201.

## Mentioned organisations, terms and topics
- **Organisations:** Meridian AI, OAIS, Publishers Alliance, Department for Digital Affairs, Halden Robotics, Office for AI Standards, Parliament, National Quantum Hub, Corvane Research, TechUK Forum
- **Terms:** data, bill, quantum, cyber, AI Liability Bill, copyright, regulation, semiconductor, chip, framework
- **Topics:** testing, digital, investment, online, safety, office

## Sources
1. [Meridian AI signs licensing deal with publishers over training data](https://example.org/sample-news/meridian-ai-copyright-deal) — Sample feed – Technology
2. [National quantum network trial links three cities](https://example.org/sample-news/quantum-network-trial) — Sample feed – Technology
3. [Halden Robotics announces semiconductor plant in north-east England](https://example.org/sample-news/halden-robotics-chip-plant) — Sample feed – Technology
4. [Office for AI Standards opens consultation on frontier model testing](https://example.org/sample-news/ai-standards-office-consultation) — Sample feed – Technology
5. [Retailer Larkfield says cyber attack disrupted online orders](https://example.org/sample-news/cyber-attack-retailer) — Sample feed – Technology
6. [AI Liability Bill clears second reading in Parliament](https://example.org/sample-news/ai-liability-bill-second-reading) — Sample feed – Politics
7. [Gigabit broadband reaches 80% of homes, rural gap remains](https://example.org/sample-news/broadband-rollout-rural) — Sample feed – Technology
8. [Online safety regulator issues guidance on chatbots used by children](https://example.org/sample-news/ofdc-chatbot-children-guidance) — Sample feed – Technology

## Evaluation
- passed: **True** · score: **0.96** · revisions: 0
- summary_word_count: 106
- summary_length_ok: True
- takeaways_count: 5
- takeaways_count_ok: True
- takeaways_distinct: True
- numbers_grounded: True
- entity_grounding: 1.0
- lexical_support: 1.0
- article_coverage: 0.75
