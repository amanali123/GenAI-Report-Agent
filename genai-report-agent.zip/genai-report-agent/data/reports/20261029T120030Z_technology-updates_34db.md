# Technology Updates — report
_Generated 2026-10-29T12:00:30.150166+00:00 · method: extractive · 5 sources_

## Summary
Smartphone makers are increasingly running AI models directly on devices instead of relying on cloud data centres. The Department for Digital Affairs has published an AI assurance standard that public bodies must follow when using algorithms to make decisions about people. The Online Safety Commission has opened an investigation into FaceSwapr, an app that lets users create deepfake images of real people. Data centres will be designated as critical national infrastructure, allowing faster planning decisions, the Department for Digital Affairs has announced. The Office for AI Standards has launched a regulatory sandbox allowing 20 AI start-ups to test products under supervision.

## Key takeaways
- The Department for Digital Affairs has published an AI assurance standard that public bodies must follow when using algorithms to make decisions about people.
- The Online Safety Commission has opened an investigation into FaceSwapr, an app that lets users create deepfake images of real people.
- Smartphone makers are increasingly running AI models directly on devices instead of relying on cloud data centres.
- Data centres will be designated as critical national infrastructure, allowing faster planning decisions, the Department for Digital Affairs has announced.
- The Office for AI Standards has launched a regulatory sandbox allowing 20 AI start-ups to test products under supervision.

## Mentioned organisations, terms and topics
- **Organisations:** Department for Digital Affairs, Online Safety Commission, TechUK Forum, Office for AI Standards, Corvane Research, Open Rights Collective, OAIS
- **Terms:** data, deepfake, cloud, AI Liability Bill, bill, code of practice, regulation, model, framework
- **Topics:** campaigners, department, centres, affairs, digital, power

## Sources
1. [Phone makers race to add on-device AI features](https://example.org/sample-news/smartphone-ai-features) — Sample feed – Technology
2. [Department for Digital Affairs publishes AI assurance standard for public sector](https://example.org/sample-news/ai-assurance-standard) — Sample feed – Politics
3. [Online Safety Commission investigates deepfake app](https://example.org/sample-news/deepfake-app-investigation) — Sample feed – Technology
4. [Government fast-tracks planning for data centres](https://example.org/sample-news/data-centre-planning) — Sample feed – Technology
5. [Office for AI Standards launches regulatory sandbox for start-ups](https://example.org/sample-news/oais-sandbox-launch) — Sample feed – Technology

## Evaluation
- passed: **True** · score: **1.00** · revisions: 0
- summary_word_count: 101
- summary_length_ok: True
- takeaways_count: 5
- takeaways_count_ok: True
- takeaways_distinct: True
- numbers_grounded: True
- entity_grounding: 1.0
- lexical_support: 1.0
- article_coverage: 1.0
