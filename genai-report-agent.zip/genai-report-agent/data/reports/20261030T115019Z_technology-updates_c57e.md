# Technology Updates — report
_Generated 2026-10-30T11:50:19.273835+00:00 · method: llm:anthropic/claude-sonnet-5-5 · 7 sources_

## Summary
AI's physical and financial footprint dominated this briefing. Data centre expansion to power AI services, now about 12,250 sites worldwide, is fuelling local backlash over energy, water and noise, with 16 US states proposing restrictions even as industry spending is forecast at $765bn in 2026. Big Tech earnings showed the strain and the promise: Alphabet lost over $500bn in market value as AI summaries hit search ad revenue, while Amazon and Microsoft reported growth alongside negative free cash flow or job cuts. In India, workers are paid to film their work to train "physical AI". Elsewhere, technology is being applied to practical problems, including genetic genealogy and AI in cold cases, odour-monitoring "electronic noses", and UKHSA's improved norovirus typing, while the UK government unveiled voluntary standards and programmes to support women in tech.

## Key takeaways
- About 12,250 data centres now operate worldwide, up from around 8,000 in 2021, and 16 US states have proposed laws to ban or temporarily block new ones.
- Alphabet's market value fell from $3.97 trillion to $3.46 trillion after results showed AI summaries in Google Search affecting ad revenue, even as Google Cloud grew 103%.
- Indian firms such as Rashdan Technologies and Humyn Labs pay workers to record their hands at work with head-mounted cameras to train robot-controlling "physical AI".
- The UK government will work with industry on a voluntary "Tech Forward Standard" and "Inclusive Investment Standard", with a women's scale-up programme launching in 2027.
- Investigative genetic genealogy from Othram helped identify a suspect in a 1993 Illinois murder, but experts raised privacy concerns and the UK is still only studying its adoption.

## Mentioned organisations, terms and topics
- **Organisations:** BBC News, Data Center Map, Brookings, GOV.UK, Women in Tech Taskforce, BT, Revolut, Sage, Balderton Capital, Octopus Ventures, DCMS, BIST, Madison County Sheriff's Office, Othram, CentralSquare, King's College London, Home Office, Rashdan Technologies, Humyn Labs, Tata Institute of Social Sciences, Alphabet, Google, Google Cloud, Amazon, Microsoft, Kunak, Smithfield Foods, Environmental Protection Agency, UKHSA
- **Terms:** AI infrastructure, AI summaries, Tech Forward Standard, Inclusive Investment Standard, TechFirst Girls Competition, Get Tech Certified, TechFirst Women's Programme, investigative genetic genealogy, Centerline AI platform, physical AI, Bedrock, Copilot, electronic noses, regenerative thermal oxidiser, norovirus dual-typing method, GII.4[P16], Hospital Norovirus Outbreak Reporting System (HNORS)
- **Topics:** Data centres, Artificial intelligence, Public backlash and energy use, US midterm elections, Big Tech earnings, Women in tech, Venture capital and investment bias, Forensic technology and privacy, AI training data and automation, Odour control and environmental monitoring, Public health surveillance

## Sources
1. [Big, noisy and coming to a town near you - why the data centre backlash is growing](https://www.bbc.co.uk/news/articles/cq2e9we7w2ejo) — BBC News – Technology
2. [Government and industry to take on investment bias and workplace culture to support more women in tech](https://www.gov.uk/government/news/government-and-industry-to-take-on-investment-bias-and-workplace-culture-to-support-more-women-in-tech) — GOV.UK – News and communications
3. [The tech helping crack decades-old cold cases](https://www.bbc.co.uk/news/articles/c370pzdkw77jo) — BBC News – Business
4. [The Indian workers filming their work to train AI](https://www.bbc.co.uk/news/articles/ckvgyml6pdm9o) — BBC News – Business
5. [Google value plunges by $500bn as AI search hits ad sales](https://www.bbc.co.uk/news/articles/cm9qzdqpxy48o) — BBC News – Technology
6. [Living with a stink? Technology might help](https://www.bbc.co.uk/news/articles/cr6240q1w136o) — BBC News – Business
7. [Latest weekly winter virus surveillance data](https://www.gov.uk/government/news/latest-ukhsa-weekly-winter-virus-surveillance-data) — GOV.UK – News and communications

## Evaluation
- passed: **True** · score: **0.91** · revisions: 0
- summary_word_count: 133
- summary_length_ok: True
- takeaways_count: 5
- takeaways_count_ok: True
- takeaways_distinct: True
- numbers_grounded: True
- entity_grounding: 0.87
- lexical_support: 0.79
- article_coverage: 0.71
- judge_faithfulness: 5
- judge_relevance: 4
