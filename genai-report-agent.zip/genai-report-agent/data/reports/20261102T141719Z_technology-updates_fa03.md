# Technology Updates — report
_Generated 2026-11-02T14:17:19.625600+00:00 · method: llm:anthropic/claude-sonnet-5-5 · 3 sources_

## Summary
Technology coverage ranges from infrastructure and security to science and the environment. A suspected cyber-attack hit refrigeration systems in dozens of supermarkets across six European countries, including about 40 Delhaize stores in Belgium and Luxembourg. Evaporators were switched to defrost mode, the method believed to have been used in an attack on hundreds of French supermarkets in early October. Manufacturer Sabcobel says the vulnerability needs physical modifications, not just software updates, and Belgium's and Sweden's national cyber-security agencies are monitoring while it is unclear who is behind it. Elsewhere, BBC programmes explore where data centres should be built, including an entrepreneur's plan for a virtual data centre in space using satellite computing power, whether rotating sails could cut container ship pollution, and NASA scientists studying a rare total solar eclipse in Iceland.

## Key takeaways
- A suspected cyber-attack hit supermarket refrigeration systems in Belgium, Luxembourg, Sweden, Ireland, the Netherlands and Estonia, affecting about 40 Delhaize stores in Belgium and Luxembourg.
- Evaporators were switched to defrost mode, the method believed to have been used in an attack on hundreds of French supermarkets in early October.
- Sabcobel CEO Stephan Moelans said the vulnerability needs physical modifications rather than just software updates, and that managing the fridges over a secure internet connection is the simplest fix.
- Belgium's and Sweden's national cyber-security agencies are monitoring the incident, and it is unclear who is behind it.
- BBC's Tech Life examines where data centres should be built, including an entrepreneur's idea of a virtual data centre in space using satellite computing power.

## Mentioned organisations, terms and topics
- **Organisations:** BBC, BBC World Service, NASA, Delhaize, Sabcobel
- **Terms:** cyber-attack, refrigeration systems, evaporators, defrost mode, virtual data centre, data centres, rotating sails, total solar eclipse
- **Topics:** cyber-security, data centres, supermarket refrigeration, shipping pollution, space, social media and AI

## Sources
1. [Tech Life](https://www.bbc.co.uk/sounds/play/w3ct8jyk) — BBC News – Technology
2. [Tech Now](https://www.bbc.co.uk/iplayer/episode/m0032301) — BBC News – Technology
3. [Shop freezers in six European countries hit by suspected cyber-attack](https://www.bbc.co.uk/news/articles/cq1kd1nee80eo) — BBC News – Business _(background)_

## Evaluation
- passed: **True** · score: **0.89** · revisions: 1
- summary_word_count: 132
- summary_length_ok: True
- takeaways_count: 5
- takeaways_count_ok: True
- takeaways_distinct: True
- numbers_grounded: True
- entity_grounding: 0.92
- lexical_support: 0.79
- article_coverage: 0.67
- judge_faithfulness: 4
- judge_relevance: 4
