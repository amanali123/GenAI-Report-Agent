# LangGraph workflows

## Report graph

```mermaid
---
config:
  flowchart:
    curve: linear
---
graph TD;
	__start__([<p>__start__</p>]):::first
	plan_collection(plan_collection)
	collect(collect)
	process(process)
	summarise(summarise)
	evaluate(evaluate)
	revise(revise)
	save(save)
	__end__([<p>__end__</p>]):::last
	__start__ --> plan_collection;
	collect --> process;
	evaluate -.-> revise;
	evaluate -.-> save;
	plan_collection --> collect;
	process -.-> __end__;
	process -.-> summarise;
	revise --> evaluate;
	summarise --> evaluate;
	save --> __end__;
	classDef default fill:#f2f0ff,line-height:1.2
	classDef first fill-opacity:0
	classDef last fill:#bfb6fc
```

## Chat graph

```mermaid
---
config:
  flowchart:
    curve: linear
---
graph TD;
	__start__([<p>__start__</p>]):::first
	analyse(analyse)
	retrieve(retrieve)
	respond(respond)
	__end__([<p>__end__</p>]):::last
	__start__ --> analyse;
	analyse --> retrieve;
	retrieve --> respond;
	respond --> __end__;
	classDef default fill:#f2f0ff,line-height:1.2
	classDef first fill-opacity:0
	classDef last fill:#bfb6fc
```
