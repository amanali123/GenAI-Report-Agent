# Technical write-up — GenAI Report Agent

## 1. Problem understanding

The system has to do three things reliably and unattended: **(a)** pull fresh, topic-relevant text from trusted sites, **(b)** turn it into a tightly specified report every hour (100–150-word summary, 3–5 takeaways, entities), and **(c)** answer free-form questions — including context-free ones like *“What’s happening nowadays?”* — from those reports rather than from the model’s own memory.

The real difficulties are not the happy path but the edges: hours with no news or only one article, the same story arriving twice, pages that fail to load, an LLM that writes 180 words or invents a figure, follow-up questions (“why?”) that mean nothing on their own, and questions the reports simply don’t cover. The design is driven by those cases.

## 2. Solution overview

Two LangGraph state machines share a small file-based store.

**Report graph** (`report_graph.py`, runs hourly via APScheduler):

| Node | What it does |
|---|---|
| `plan_collection` | Emits one **tool call per trusted source** (BBC Technology/Business/Politics RSS, GOV.UK news Atom search) with already-seen URLs to skip. |
| `collect` | LangGraph **`ToolNode`** executes the `fetch_source_articles` tool: feed → keyword relevance filter → scrape article page with BeautifulSoup (site-aware selectors) → clean (boilerplate removal, paragraph de-dup, length cap). Errors are returned as data, not raised. |
| `process` | Merges sources, de-dupes by URL and normalised title, ranks by relevance, caps the count. If 1–2 new articles, **backfills** recent already-reported ones as clearly-flagged *background* so the model never has to pad a 100-word summary from one article. Zero new → ends (“reports still current”). |
| `summarise` | **Map-reduce**: each article → 2–4 fact-dense notes (parallel `.batch`, drops `NOT_RELEVANT`); notes → `ReportDraft` via **structured output** (Pydantic schema). |
| `evaluate` | Deterministic checks + optional LLM-as-judge (section 4). |
| `revise` | On failure, the draft *and the evaluator’s specific feedback* (“has 172 words”, “2.5% not in sources”) go back to the model; loops at most `MAX_REVISIONS` times. |
| `save` | Writes JSON + Markdown, marks URLs seen, caches article text for chat. |

`APScheduler` runs it with `max_instances=1, coalesce=True` (a slow run never overlaps the next; missed ticks collapse). `python main.py report` is the manual trigger; `demo` simulates successive hours with batched sample data.

**Chat graph** (`chat_graph.py`): `analyse → retrieve → respond`, compiled with a `MemorySaver` checkpointer keyed by `thread_id`.

* `analyse` classifies intent — *overview* (vague), *topical*, *follow-up*, *small talk* — and rewrites follow-ups into standalone queries (LLM rewrite; heuristic fallback offline).
* `retrieve`: overview → latest report per topic; otherwise BM25 + recency over report summaries, takeaways and article excerpts, with a confidence score.
* `respond`: LLM answers from a context block where every report carries an `[R#]` id and timestamp, under rules to cite, date, and say “not covered” rather than guess.

## 3. Key GenAI concepts used and why

* **Map-reduce summarisation.** Bounded context per call (articles can be long), parallelism, and the reduce step synthesises *across* articles instead of concatenating per-article summaries. It also gives a natural place to filter irrelevant articles semantically (`NOT_RELEVANT`) after the cheap keyword pre-filter.
* **Structured output.** The report has a contract (fields, counts). Schema-constrained generation (`with_structured_output`, JSON-schema mode on Anthropic) removes brittle text parsing and makes the output directly evaluable.
* **Generate → evaluate → revise (reflection loop).** Length windows are something LLMs routinely miss; targeted, machine-generated feedback fixes this in one revision far more reliably than a stronger prompt. The loop is bounded, and a failed report is still saved with its scorecard rather than silently dropped.
* **Grounding & hallucination controls.** Every number in the output must appear in the sources; entities must appear verbatim; an LLM judge scores faithfulness. These target the failure that matters most in a news product — a confident, wrong figure.
* **Retrieval-augmented, report-first context engineering.** The chat context holds *reports* (dense, already validated, timestamped) plus a few article excerpts, not raw pages — cheaper, less noisy, and consistent with the brief (“respond according to the latest reports”). Context blocks are labelled for citation; history is trimmed to the last N turns because the rewritten query already carries the needed context.
* **Intent routing for vague queries.** “What’s happening nowadays?” has no useful keywords for retrieval; routing it to a *latest-per-topic* overview gives a good answer where similarity search would return noise.
* **Abstention.** Retrieval confidence is measured as the share of the query’s content words found in the best chunk (BM25 scores are not comparable across queries; coverage is). Below threshold, the model is told the question may not be covered, and the offline path refuses explicitly.

## 4. Logging and evaluation

* **Logs:** structured JSON lines (`logs/agent.jsonl`) for every node — duration, counts in/out, source errors, each eval check, retrieval confidence, intent, citations — so a bad report can be traced to “GOV.UK feed failed” vs “model ignored the word limit”.
* **Report evaluation (every run):** word count window, takeaway count and distinctness, numeric grounding, entity grounding, lexical support, article coverage, plus LLM-judge faithfulness/relevance (1–5). Hard checks gate `passed`; all checks roll into a 0–1 score stored with the report.
* **Chat evaluation (`main.py eval`):** scripted single- and multi-turn cases (vague overview, the brief’s “What’s new in AI today?”, a specific fact, follow-up topic switch, out-of-scope refusal, small talk) checking intent, content, citations, topic resolution, refusal and latency.
* **Tests:** 10 pytest cases, including the LLM path and revise loop driven by a scripted fake chat model, so CI needs no API key.

## 5. Alternatives considered and choices made

| Decision | Alternatives | Why this choice |
|---|---|---|
| **Feeds for discovery + page scraping** | Scrape section pages; Newspaper3k; news APIs | RSS/Atom are stable, cheap and list the newest items; scraping only the selected articles keeps load low. Newspaper3k has been unmaintained since 2018. |
| **Deterministic tool plan** (one call per source) executed by `ToolNode` | LLM agent decides which tools to call (ReAct) | Sources are predefined, so letting an LLM choose adds cost, latency and non-determinism with no benefit for an unattended hourly job. The tool interface keeps the option open: swapping `plan_collection` for an LLM tool-caller is a one-node change. |
| **Keyword pre-filter + LLM relevance in map step** | Embedding similarity; LLM-only filtering | Keyword scoring is free and transparent and removes most noise before paying for tokens; the map step catches what it misses. |
| **Map-reduce** | Single “stuff everything” prompt; refine chain | Stuffing breaks on long or many articles; refine is sequential and order-sensitive. |
| **Rule checks + LLM judge** | Judge only; ROUGE vs reference | No reference summaries exist for live news, so ROUGE is unusable; rule checks are free, exact and produce actionable feedback; the judge covers semantics. |
| **BM25 + recency over reports** | Vector DB with embeddings | The corpus is tens–hundreds of short chunks: BM25 is instant, dependency-free and explainable. Embeddings would help paraphrased queries; `retrieval.search` is the single swap point (e.g. FAISS + hybrid scoring) if the corpus grows. |
| **JSON/Markdown files** | SQLite, Postgres, vector store | Inspectable, zero setup, easy to submit. All I/O is in `ReportStore`. |
| **APScheduler** | cron, `schedule`, Airflow | In-process, works the same in CLI and Streamlit (background scheduler), with overlap protection. Airflow is overkill for one job. |
| **Offline extractive baseline** | Require an API key | Makes the project testable anywhere and provides a baseline to compare LLM reports against. It uses centroid TF-IDF sentence ranking with a word-budget selection to hit 100–150 words. It is a fallback, not the intended main path. |

## 6. Limitations and next steps

* Example outputs in `examples/` come from the offline baseline on **fictional sample articles** (the build environment had no internet access to BBC/GOV.UK and no API key). Live scraping is implemented and unit-tested on representative HTML but its selectors will need upkeep as sites change.
* Topic overlap (e.g. AI Regulation vs Technology Updates) means the same story can appear in two reports; a cross-topic de-dup or a single multi-topic report would fix this.
* Next: hybrid BM25 + embedding retrieval, streaming chat responses, tracing via LangSmith, a small human-labelled set to calibrate the LLM judge, and persisting chat memory (`SqliteSaver`) across restarts.
